# Getting Started

## Environment Setup

### Platform and OS Requirements:

| OS                       | Platform      | Python Version          |
|--------------------------|---------------|-------------------------|
| Windows 10               | x86_64 64-bit | 3.5-3.9 (x86_64 64-bit) |
| Ubuntu 18.04             | x86_64 64-bit | 3.5-3.9 (x86_64 64-bit) |

### Upgrade pip (pip version >= 21.X.X)

```bash
$ python -m pip install --upgrade pip
```

### General

* opencv-python (Install using `python -m pip install opencv-python`)
* numpy (Install using `python -m pip install numpy`)

### Ubuntu

```bash
# Please install python package by the following sequence
$ python -m pip install ./package/{platform}/KneronPLUS-X.X.X-py3-none-any.whl
$ python -m pip install ./package/{platform}/KneronPLUS_YOLO-X.X.X-py3-none-any.whl
```

> #### Ubuntu only step
> * Need to install libusb and config USB permission on Ubuntu 
>   ```bash
>   $ sudo bash install_libusb.sh
>   ```
> * Or add following lines in `/etc/udev/rules.d/10-local.rules`
>   ```text
>   KERNEL=="ttyUSB*",ATTRS{idVendor}=="067b",ATTRS{idProduct}=="2303",MODE="0777",SYMLINK+="kneron_uart"
>   KERNEL=="ttyUSB*",ATTRS{idVendor}=="1a86",ATTRS{idProduct}=="7523",MODE="0777",SYMLINK+="kneron_pwr"
>   SUBSYSTEM=="usb",ATTRS{idVendor}=="3231",ATTRS{idProduct}=="0100",MODE="0666"
>   SUBSYSTEM=="usb",ATTRS{idVendor}=="3231",ATTRS{idProduct}=="0200",MODE="0666"
>   SUBSYSTEM=="usb",ATTRS{idVendor}=="3231",ATTRS{idProduct}=="0720",MODE="0666"
>   ```
>   and restatr service by following command
>   ```bash
>   $ sudo udevadm trigger
>   ```

### Windows

```bash
# Please install python package by the following sequence
$ python -m pip install .\package\{platform}\KneronPLUS-X.X.X-py3-none-any.whl
$ python -m pip install .\package\{platform}\KneronPLUS_YOLO-X.X.X-py3-none-any.whl
```

## Quick Start

```bash
# Please check camera is connected firstly.
$ python cam_object_detection_80_class_light_weight.py
```

## Usage

```bash
$ python cam_object_detection_80_class_light_weight.py -h
```

* Show all input parameters for the APP.

```bash
$ python cam_object_detection_80_class_light_weight.py
```

* Run APP with first scanned kneron device.

```bash
$ python cam_object_detection_80_class_light_weight.py -p port_id
```

* Run APP with  specified port ID for connecting device (`Hint: find USB port ID by ScanDevice.py`).

```bash
$ python ScanDevice.py
```

* Show all connected Kneron AI Devices.

## Common Problem
* If pip install/run application fails, it may cause by using python 2.X as python interpreter. Please make sure the interpreter and pip is `Python 3` on the host:
    ```bash
    # check pip version
    $ pip -V
    $ pip3 -V

    # check python interpreter version
    $ python -V
    $ python3 -V
    ```

    You also can install package by specify python interpreter by following scripts:
    ```bash
    $ python -m pip install {package_path}
    # or
    $ python3 -m pip install {package_path}
    ```