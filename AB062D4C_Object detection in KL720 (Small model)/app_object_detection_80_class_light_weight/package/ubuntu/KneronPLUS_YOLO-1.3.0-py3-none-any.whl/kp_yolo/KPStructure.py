# ******************************************************************************
#  Copyright (c) 2021. Kneron Inc. All rights reserved.                        *
# ******************************************************************************

# from KP
from kp.KPBaseClass.StructureBase import BufferBase
from kp.KPStructure import BoundingBoxBuffer
from kp.KPEnum import NormalizeMode
from kp.KPConstant import Const as CoreConst

# from KPApp
from .KPConstant import Const as AppConst

from typing import List
import ctypes


class AppYoloConfigBuffer(BufferBase):
    """AppYoloConfigBuffer structure"""
    _pack_ = 4
    _fields_ = [('_model_id', ctypes.c_uint32),
                ('_model_norm', ctypes.c_uint32)]

    def _init_buffer(self,
                     model_id: int = 0,
                     model_norm: NormalizeMode = NormalizeMode.KP_NORMALIZE_KNERON) -> None:
        assert 0 <= model_id

        self._model_id = model_id
        self._model_norm = model_norm.value


class AppYoloPostProcConfigV5Buffer(BufferBase):
    """AppYoloPostProcConfigV5Buffer structure"""
    _pack_ = 4
    _fields_ = [('_prob_thresh', ctypes.c_float),
                ('_nms_thresh', ctypes.c_float),
                ('_max_detection_per_class', ctypes.c_uint32),
                ('_anchor_row', ctypes.c_uint16),
                ('_anchor_col', ctypes.c_uint16),
                ('_stride_size', ctypes.c_uint16),
                ('_reserved_size', ctypes.c_uint16),
                ('_data', ctypes.c_uint32 * AppConst.APP_POST_PROC_CONFIG_DATA_SIZE.value)]

    def _init_buffer(self,
                     prob_thresh: float = 0,
                     nms_thresh: float = 0,
                     max_detection_per_class: int = 0,
                     anchor_row: int = 0,
                     anchor_col: int = 0,
                     stride_size: int = 0,
                     reserved_size: int = 0,
                     data: List[int] = []) -> None:
        assert 0 <= max_detection_per_class
        assert 0 <= anchor_row
        assert 0 <= anchor_col
        assert 0 <= stride_size
        assert 0 == reserved_size
        assert AppConst.APP_POST_PROC_CONFIG_DATA_SIZE.value == len(data)

        self._prob_thresh = prob_thresh
        self._nms_thresh = nms_thresh
        self._max_detection_per_class = max_detection_per_class
        self._anchor_row = anchor_row
        self._anchor_col = anchor_col
        self._stride_size = stride_size
        self._reserved_size = reserved_size
        self._data = (ctypes.c_uint32 * AppConst.APP_POST_PROC_CONFIG_DATA_SIZE.value)(*data)


class AppYoloResultBuffer(BufferBase):
    """AppYoloResultBuffer structure"""
    _pack_ = 4
    _fields_ = [('_padding', ctypes.c_ubyte * CoreConst.APP_PADDING_BYTES.value),
                ('_class_count', ctypes.c_uint32),
                ('_box_count', ctypes.c_uint32),
                ('_boxes', BoundingBoxBuffer * CoreConst.YOLO_GOOD_BOX_MAX.value)]

    def _init_buffer(self,
                     class_count: int = 0,
                     box_count: int = 0,
                     box_list: List[BoundingBoxBuffer] = []) -> None:
        assert 0 <= class_count
        assert 0 <= box_count

        self._class_count = class_count
        self._box_count = box_count
        self._boxes = (BoundingBoxBuffer * CoreConst.YOLO_GOOD_BOX_MAX.value)(*box_list)
