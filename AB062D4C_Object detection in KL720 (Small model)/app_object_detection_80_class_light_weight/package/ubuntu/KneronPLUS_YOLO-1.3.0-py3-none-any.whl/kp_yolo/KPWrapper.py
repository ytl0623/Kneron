# ******************************************************************************
#  Copyright (c) 2021. Kneron Inc. All rights reserved.                        *
# ******************************************************************************

# from KP
from kp.KPBaseClass.AppWrapperBase import AppWrapperBase

# from KPApp
from .KPStructure import AppYoloConfigBuffer, AppYoloPostProcConfigV5Buffer, AppYoloResultBuffer
from .KPLibLoader import KPLibLoader
import ctypes


class KPWrapper(AppWrapperBase):
    def __init__(self):
        super(KPWrapper, self).__init__(lib_loader=KPLibLoader())

    def _init_sdk_functions(self):
        self.__init_kp_app_yolo_get_post_proc_parameters()
        self.__init_kp_app_yolo_set_post_proc_parameters()
        self.__init_kp_app_yolo_inference_send()
        self.__init_kp_app_yolo_inference_receive()

    def __init_kp_app_yolo_get_post_proc_parameters(self):
        c_function = self._lib.kp_app_yolo_get_post_proc_parameters
        c_function.argtypes = [ctypes.c_void_p,
                               ctypes.c_int,
                               ctypes.POINTER(AppYoloPostProcConfigV5Buffer)]
        c_function.restype = ctypes.c_int

    def __init_kp_app_yolo_set_post_proc_parameters(self):
        c_function = self._lib.kp_app_yolo_set_post_proc_parameters
        c_function.argtypes = [ctypes.c_void_p,
                               ctypes.c_int,
                               ctypes.POINTER(AppYoloPostProcConfigV5Buffer)]
        c_function.restype = ctypes.c_int

    def __init_kp_app_yolo_inference_send(self):
        c_function = self._lib.kp_app_yolo_inference_send
        c_function.argtypes = [ctypes.c_void_p,
                               ctypes.c_uint32,
                               ctypes.POINTER(ctypes.c_uint8),
                               ctypes.c_uint32,
                               ctypes.c_uint32,
                               ctypes.c_uint32,
                               ctypes.POINTER(AppYoloConfigBuffer)]
        c_function.restype = ctypes.c_int

    def __init_kp_app_yolo_inference_receive(self):
        c_function = self._lib.kp_app_yolo_inference_receive
        c_function.argtypes = [ctypes.c_void_p,
                               ctypes.POINTER(ctypes.c_uint32),
                               ctypes.POINTER(AppYoloResultBuffer)]
        c_function.restype = ctypes.c_int
