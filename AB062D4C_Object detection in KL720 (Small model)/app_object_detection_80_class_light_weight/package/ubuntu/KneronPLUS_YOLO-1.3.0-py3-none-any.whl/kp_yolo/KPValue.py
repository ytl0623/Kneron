# ******************************************************************************
#  Copyright (c) 2021. Kneron Inc. All rights reserved.                        *
# ******************************************************************************

# from KP
from kp.KPBaseClass.ValueBase import ValueRepresentBase, ValueBase
from kp.KPStructure import BoundingBoxBuffer
from kp.KPValue import BoundingBox
from kp.KPEnum import NormalizeMode

# from KPApp
from .KPConstant import Const as AppConst
from .KPStructure import AppYoloConfigBuffer, AppYoloPostProcConfigV5Buffer, AppYoloResultBuffer
from typing import List
import numpy as np
import ctypes


class AppYoloConfig(ValueBase, ValueRepresentBase):
    """
    YOLO APP inference configuration.

    Attributes
    ----------
    model_id : int, default=0
        Target inference model ID.
    model_norm : kp_yolo.NormalizeMode, default=kp_yolo.NormalizeMode.KP_NORMALIZE_KNERON
        Inference normalization, refer to NormalizeMode.
    """

    def __init__(self,
                 model_id: int = 0,
                 model_norm: NormalizeMode = NormalizeMode.KP_NORMALIZE_KNERON):
        """
        YOLO APP inference configuration.

        Parameters
        ----------
        model_id : int, default=0
            Target inference model ID.
        model_norm : kp_yolo.NormalizeMode, default=kp_yolo.NormalizeMode.KP_NORMALIZE_KNERON
            Inference normalization, refer to NormalizeMode.
        """
        ValueBase.__init__(self,
                           element_buffer_class=AppYoloConfigBuffer,
                           model_id=model_id,
                           model_norm=model_norm)

    def _cast_element_buffer(self) -> None:
        pass

    @property
    def model_id(self) -> int:
        """
        int: Target inference model ID.
        """
        return self._element_buffer._model_id

    @model_id.setter
    def model_id(self, value: int):
        self._element_buffer._model_id = value

    @property
    def model_norm(self) -> NormalizeMode:
        """
        kp_yolo.NormalizeMode: Inference normalization, refer to NormalizeMode.
        """
        return NormalizeMode(self._element_buffer._model_norm)

    @model_norm.setter
    def model_norm(self, value: NormalizeMode):
        self._element_buffer._model_norm = value.value

    def get_member_variable_dict(self) -> dict:
        return {
            'model_id': self.model_id,
            'model_norm': str(self.model_norm)
        }


class AppYoloPostProcConfig(ValueBase, ValueRepresentBase):
    """
    YOLO APP inference configuration - post-process configurations for YOLO series.

    Attributes
    ----------
    prob_thresh : float, default=0
        Probability threshold.
    nms_thresh : float, default=0
        NMS (Non-Maximum Suppression) threshold.
    max_detection_per_class : int, default=0
        Maximum number of detection per class.
    anchors : numpy.ndarray, default=np.array([[[0, 0], [0, 0], [0, 0]], [[0, 0], [0, 0], [0, 0]], [[0, 0], [0, 0], [0, 0]]])
        Anchor configuration.
    strides : numpy.ndarray, default=np.array([0, 0, 0])
        Stride configuration of anchor.
    """

    def __init__(self,
                 prob_thresh: float = 0,
                 nms_thresh: float = 0,
                 max_detection_per_class: int = 0,
                 anchors: np.ndarray = np.array([[[0, 0], [0, 0], [0, 0]],
                                                 [[0, 0], [0, 0], [0, 0]],
                                                 [[0, 0], [0, 0], [0, 0]]]),
                 strides: np.ndarray = np.array([0, 0, 0])):
        """
        YOLO APP inference configuration - post-process configurations for YOLO series.

        Attributes
        ----------
        prob_thresh : float, default=0
            Probability threshold.
        nms_thresh : float, default=0
            NMS (Non-Maximum Suppression) threshold.
        max_detection_per_class : int, default=0
            Maximum number of detection per class.
        anchors : numpy.ndarray, default=np.array([[[0, 0], [0, 0], [0, 0]], [[0, 0], [0, 0], [0, 0]], [[0, 0], [0, 0], [0, 0]]])
            Anchor configuration.
        strides : numpy.ndarray, default=np.array([0, 0, 0])
            Stride configuration of anchor.
        """
        assert 3 == len(anchors.shape)
        assert 1 == len(strides.shape)
        assert 2 == anchors.shape[2]

        data = anchors.flatten().tolist()
        data += strides.flatten().tolist()
        data += (AppConst.APP_POST_PROC_CONFIG_DATA_SIZE.value - len(data)) * [0]

        assert AppConst.APP_POST_PROC_CONFIG_DATA_SIZE.value == len(data)

        ValueBase.__init__(self,
                           element_buffer_class=AppYoloPostProcConfigV5Buffer,
                           prob_thresh=round(prob_thresh, 6),
                           nms_thresh=round(nms_thresh, 6),
                           max_detection_per_class=max_detection_per_class,
                           anchor_row=anchors.shape[0],
                           anchor_col=anchors.shape[1] * anchors.shape[2],
                           stride_size=strides.shape[0],
                           reserved_size=0,
                           data=data)

    def _cast_element_buffer(self) -> None:
        pass

    @property
    def prob_thresh(self) -> float:
        """
        float: Probability threshold.
        """
        return round(self._element_buffer._prob_thresh, 6)

    @prob_thresh.setter
    def prob_thresh(self, value: float):
        self._element_buffer._prob_thresh = round(value, 6)

    @property
    def nms_thresh(self) -> float:
        """
        float: NMS (Non-Maximum Suppression) threshold.
        """
        return round(self._element_buffer._nms_thresh, 6)

    @nms_thresh.setter
    def nms_thresh(self, value: float):
        self._element_buffer._nms_thresh = round(value, 6)

    @property
    def max_detection_per_class(self) -> int:
        """
        int: Maximum number of detection per class.
        """
        return self._element_buffer._max_detection_per_class

    @max_detection_per_class.setter
    def max_detection_per_class(self, value: int):
        self._element_buffer._max_detection_per_class = value

    @property
    def anchors(self) -> np.ndarray:
        """
        numpy.ndarray: Anchor configuration.
        """
        anchors = np.array(
            self._element_buffer._data[:self._element_buffer._anchor_row * self._element_buffer._anchor_col])
        return anchors.reshape((self._element_buffer._anchor_row,
                                int(self._element_buffer._anchor_col / 2),
                                2))

    @anchors.setter
    def anchors(self, value: np.ndarray):
        assert 3 == len(value.shape)
        assert 2 == value.shape[2]

        data = value.flatten().tolist()
        data += self.strides.flatten().tolist()
        data += (AppConst.APP_POST_PROC_CONFIG_DATA_SIZE.value - len(data)) * [0]

        assert AppConst.APP_POST_PROC_CONFIG_DATA_SIZE.value == len(data)

        self._element_buffer._anchor_row = value.shape[0]
        self._element_buffer._anchor_col = value.shape[1] * value.shape[2]
        self._element_buffer._data = (ctypes.c_uint32 * AppConst.APP_POST_PROC_CONFIG_DATA_SIZE.value)(*data)

    @property
    def strides(self) -> np.ndarray:
        """
        numpy.ndarray: Stride configuration of anchor.
        """
        return np.array(
            self._element_buffer._data[self._element_buffer._anchor_row * self._element_buffer._anchor_col:][
            :self._element_buffer._stride_size])

    @strides.setter
    def strides(self, value: np.ndarray):
        assert 1 == len(value.shape)

        data = self.anchors.flatten().tolist()
        data += value.flatten().tolist()
        data += (AppConst.APP_POST_PROC_CONFIG_DATA_SIZE.value - len(data)) * [0]

        assert AppConst.APP_POST_PROC_CONFIG_DATA_SIZE.value == len(data)

        self._element_buffer._stride_size = value.shape[0]
        self._element_buffer._data = (ctypes.c_uint32 * AppConst.APP_POST_PROC_CONFIG_DATA_SIZE.value)(*data)

    def get_member_variable_dict(self) -> dict:
        return {
            'prob_thresh': self.prob_thresh,
            'nms_thresh': self.nms_thresh,
            'max_detection_per_class': self.max_detection_per_class,
            'anchors': self.anchors,
            'strides': self.strides
        }

    def __copy__(self):
        return AppYoloPostProcConfig(
            prob_thresh=self.prob_thresh,
            nms_thresh=self.nms_thresh,
            max_detection_per_class=self.max_detection_per_class,
            anchors=self.anchors.copy(),
            strides=self.strides.copy()
        )

    def copy(self) -> 'AppYoloPostProcConfig':
        """
        Return a copy of the AppYoloPostProcConfigV5.

        Returns
        -------
        app_yolo_post_proc_config : kp_yolo.AppYoloPostProcConfig
            a copy of the AppYoloPostProcConfig.
        """
        return self.__copy__()


class AppYoloPostProcConfigV3(AppYoloPostProcConfig):
    """
    YOLO APP inference configuration - post-process configurations for YOLO v3 series.

    Attributes
    ----------
    prob_thresh : float, default=0.2
        Probability threshold.
    nms_thresh : float, default=0.45
        NMS (Non-Maximum Suppression) threshold.
    max_detection_per_class : int, default=20
        Maximum number of detection per class.
    anchors : numpy.ndarray, default=np.array([[[81, 82], [135, 169], [344, 319]], [[23, 27], [37, 58], [81, 82]], [[4, 9], [13, 24], [24, 50]]])
        Anchor configuration.
    strides : numpy.ndarray, default=np.array([8, 16, 32])
        Stride configuration of anchor.
    """

    def __init__(self,
                 prob_thresh: float = 0.2,
                 nms_thresh: float = 0.45,
                 max_detection_per_class: int = 20,
                 anchors: np.ndarray = np.array([[[81, 82], [135, 169], [344, 319]],
                                                 [[23, 27], [37, 58], [81, 82]],
                                                 [[4, 9], [13, 24], [24, 50]]]),
                 strides: np.ndarray = np.array([8, 16, 32])):
        """
        YOLO APP inference configuration - post-process configurations for YOLO v3 series.

        Attributes
        ----------
        prob_thresh : float, default=0.2
            Probability threshold.
        nms_thresh : float, default=0.45
            NMS (Non-Maximum Suppression) threshold.
        max_detection_per_class : int, default=20
            Maximum number of detection per class.
        anchors : numpy.ndarray, default=np.array([[[81, 82], [135, 169], [344, 319]], [[23, 27], [37, 58], [81, 82]], [[4, 9], [13, 24], [24, 50]]])
            Anchor configuration.
        strides : numpy.ndarray, default=np.array([8, 16, 32])
            Stride configuration of anchor.
        """
        super(AppYoloPostProcConfigV3, self).__init__(prob_thresh=prob_thresh,
                                                      nms_thresh=nms_thresh,
                                                      max_detection_per_class=max_detection_per_class,
                                                      anchors=anchors,
                                                      strides=strides)


class AppYoloPostProcConfigV5(AppYoloPostProcConfig):
    """
    YOLO APP inference configuration - post-process configurations for YOLO v5 series.

    Attributes
    ----------
    prob_thresh : float, default=0.15
        Probability threshold.
    nms_thresh : float, default=0.5
        NMS (Non-Maximum Suppression) threshold.
    max_detection_per_class : int, default=20
        Maximum number of detection per class.
    anchors : numpy.ndarray, default=np.ndarray([[[10, 13], [16, 30], [33, 23]], [[30, 61], [62, 45], [59, 119]], [[116, 90], [156, 198], [373, 326]]])
        Anchor configuration.
    strides : numpy.ndarray, default=np.ndarray([8, 16, 32])
        Stride configuration of anchor.
    """

    def __init__(self,
                 prob_thresh: float = 0.15,
                 nms_thresh: float = 0.5,
                 max_detection_per_class: int = 20,
                 anchors: np.ndarray = np.array([[[10, 13], [16, 30], [33, 23]],
                                                 [[30, 61], [62, 45], [59, 119]],
                                                 [[116, 90], [156, 198], [373, 326]]]),
                 strides: np.ndarray = np.array([8, 16, 32])):
        """
        YOLO APP inference configuration - post-process configurations for YOLO v5 series.

        Parameters
        ----------
        prob_thresh : float, default=0.15
            Probability threshold.
        nms_thresh : float, default=0.5
            NMS (Non-Maximum Suppression) threshold.
        max_detection_per_class : int, default=20
            Maximum number of detection per class.
        anchors : numpy.ndarray, default=np.array([[[10, 13], [16, 30], [33, 23]], [[30, 61], [62, 45], [59, 119]], [[116, 90], [156, 198], [373, 326]]])
            Anchor configuration.
        strides : numpy.ndarray, default=np.array([8, 16, 32])
            Stride configuration of anchor.
        """
        super(AppYoloPostProcConfigV5, self).__init__(prob_thresh=prob_thresh,
                                                      nms_thresh=nms_thresh,
                                                      max_detection_per_class=max_detection_per_class,
                                                      anchors=anchors,
                                                      strides=strides)


class AppYoloResult(ValueBase, ValueRepresentBase):
    """
    APP YOLO output result descriptor.

    Attributes
    ----------
    class_count : int, default=0
        Total detectable class count.
    box_count : int, default=0
        Total bounding box number.
    box_list : List[kp_yolo.BoundingBox], default=[]
        bounding boxes.
    """

    def __init__(self,
                 class_count: int = 0,
                 box_count: int = 0,
                 box_list: List[BoundingBox] = []):
        """
        APP YOLO output result descriptor.

        Parameters
        ----------
        class_count : int, default=0
            Total detectable class count.
        box_count : int, default=0
            Total bounding box number.
        box_list : List[kp_yolo.BoundingBox], default=[]
            bounding boxes.
        """
        ValueBase.__init__(self,
                           element_buffer_class=AppYoloResultBuffer,
                           class_count=class_count,
                           box_count=box_count,
                           box_list=[BoundingBoxBuffer(x1=bounding_box.x1,
                                                       y1=bounding_box.y1,
                                                       x2=bounding_box.x2,
                                                       y2=bounding_box.y2,
                                                       score=bounding_box.score,
                                                       class_num=bounding_box.class_num) for bounding_box in box_list])

    def _cast_element_buffer(self) -> None:
        pass

    @property
    def class_count(self) -> int:
        """
        int: Total detectable class count.
        """
        return self._element_buffer._class_count

    @property
    def box_count(self) -> int:
        """
        int: Total bounding box number.
        """
        return self._element_buffer._box_count

    @property
    def box_list(self) -> List[BoundingBox]:
        """
        List[kp_yolo.BoundingBox]: bounding boxes.
        """
        return [BoundingBox(x1=box._x1,
                            y1=box._y1,
                            x2=box._x2,
                            y2=box._y2,
                            score=box._score,
                            class_num=box._class_num) for box in
                self._element_buffer._boxes[:self._element_buffer._box_count]]

    def get_member_variable_dict(self) -> dict:
        member_variable_dict = {
            'class_count': self.class_count,
            'box_count': self.box_count,
            'box_list': {}
        }

        for idx, box_element in enumerate(self.box_list):
            member_variable_dict['box_list'][idx] = box_element.get_member_variable_dict()

        return member_variable_dict
