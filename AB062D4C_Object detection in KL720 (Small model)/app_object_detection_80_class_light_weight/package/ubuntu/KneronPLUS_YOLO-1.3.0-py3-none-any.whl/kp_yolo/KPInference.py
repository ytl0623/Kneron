# ******************************************************************************
#  Copyright (c) 2021. Kneron Inc. All rights reserved.                        *
# ******************************************************************************

# from KP
from kp.KPEnum import \
    ApiReturnCode, \
    ImageFormat
from kp.KPValue import \
    DeviceGroup
from kp.KPException import _check_api_return_code
from kp.KPInference import KPInference as KPInferenceCore

# from KPApp
from .KPValue import \
    AppYoloConfig, \
    AppYoloPostProcConfig, \
    AppYoloResult
from .KPWrapper import KPWrapper

from typing import Tuple, Union
import numpy as np
import ctypes


class KPInference(KPInferenceCore):
    __KP_WRAPPER = KPWrapper()

    @staticmethod
    def app_yolo_get_post_proc_config(device_group: DeviceGroup,
                                      model_id: int) -> AppYoloPostProcConfig:
        """
        Get YOLO series post-process configurations.

        Parameters
        ----------
        device_group : kp_yolo.DeviceGroup
            Represents a set of devices handle.
        model_id : int
            Target inference model ID.

        Raises
        ------
        kp_yolo.ApiKPException

        See Also
        --------
        kp.core.connect_devices : To connect multiple (including one) Kneron devices.
        kp_yolo.inference.app_yolo_inference_receive : Receive inference result of YOLO.
        kp_yolo.app_yolo_set_post_proc_config : Set YOLO series post-process configurations.
        kp_yolo.AppYoloPostProcConfig
        """
        app_yolo_post_proc_config = AppYoloPostProcConfig()

        status = KPInference.__KP_WRAPPER.LIB.kp_app_yolo_get_post_proc_parameters(device_group.address,
                                                                                   model_id,
                                                                                   ctypes.byref(
                                                                                       app_yolo_post_proc_config._get_element_buffer()))

        _check_api_return_code(result=app_yolo_post_proc_config,
                               api_return_code=ApiReturnCode(status))

        return app_yolo_post_proc_config

    @staticmethod
    def app_yolo_set_post_proc_config(device_group: DeviceGroup,
                                      model_id: int,
                                      app_yolo_post_proc_config: AppYoloPostProcConfig) -> None:
        """
        Set YOLO series post-process configurations.

        Parameters
        ----------
        device_group : kp_yolo.DeviceGroup
            Represents a set of devices handle.
        model_id : int
            Target inference model ID.
        app_yolo_post_proc_config : kp_yolo.AppYoloPostProcConfig
            YOLO post-process configurations, refer to kp_yolo.AppYoloPostProcConfigV3 and kp_yolo.AppYoloPostProcConfigV5.

        Raises
        ------
        kp_yolo.ApiKPException

        See Also
        --------
        kp.core.connect_devices : To connect multiple (including one) Kneron devices.
        kp_yolo.inference.app_yolo_inference_receive : Receive inference result of YOLO.
        kp_yolo.ImageFormat
        kp_yolo.AppYoloPostProcConfig
        kp_yolo.AppYoloPostProcConfigV3
        kp_yolo.AppYoloPostProcConfigV5
        """
        status = KPInference.__KP_WRAPPER.LIB.kp_app_yolo_set_post_proc_parameters(device_group.address,
                                                                                   model_id,
                                                                                   ctypes.byref(
                                                                                       app_yolo_post_proc_config._get_element_buffer()))

        _check_api_return_code(result=None,
                               api_return_code=ApiReturnCode(status))

    @staticmethod
    def app_yolo_inference_send(device_group: DeviceGroup,
                                inference_number: int,
                                app_yolo_config: AppYoloConfig,
                                image: Union[bytes, np.ndarray],
                                image_format: ImageFormat,
                                image_width: Union[int, None] = None,
                                image_height: Union[int, None] = None) -> None:
        """
        Send image for YOLO inference.

        Parameters
        ----------
        device_group : kp_yolo.DeviceGroup
            Represents a set of devices handle.
        inference_number : int
            Inference sequence number.
        app_yolo_config : kp_yolo.AppYoloConfig
            YOLO APP inference configuration.
        image : bytes, numpy.ndarray
            The data bytes or numpy.ndarray contains the image.
        image_format : kp_yolo.ImageFormat
            Image format supported for inference.
        image_width : int, default=None
            Inference image width (Must given when input bytes image data).
        image_height : int, default=None
            Inference image height (Must given when input bytes image data).

        Raises
        ------
        kp_yolo.ApiKPException

        See Also
        --------
        kp.core.connect_devices : To connect multiple (including one) Kneron devices.
        kp_yolo.inference.app_yolo_inference_receive : Receive inference result of YOLO.
        kp_yolo.ImageFormat
        kp_yolo.AppYoloConfig
        """
        if isinstance(image, np.ndarray):
            image_width = image.shape[1]
            image_height = image.shape[0]
            image = image.tobytes()

        assert image_width is not None
        assert image_height is not None

        image_buffer_c_array = (ctypes.c_ubyte * len(image)).from_buffer(bytearray(image))

        status = KPInference.__KP_WRAPPER.LIB.kp_app_yolo_inference_send(device_group.address,
                                                                         inference_number,
                                                                         image_buffer_c_array,
                                                                         image_width,
                                                                         image_height,
                                                                         image_format.value,
                                                                         ctypes.byref(
                                                                             app_yolo_config._get_element_buffer()))

        _check_api_return_code(result=None,
                               api_return_code=ApiReturnCode(status))

    @staticmethod
    def app_yolo_inference_receive(device_group: DeviceGroup) -> Tuple[int, AppYoloResult]:
        """
        Receive inference result of YOLO.

        Parameters
        ----------
        device_group : kp_yolo.DeviceGroup
            Represents a set of devices handle.

        Returns
        -------
        inference_number : int
            Inference sequence number.
        app_yolo_result : kp_yolo.AppYoloResult
            YOLO inference result.

        Raises
        ------
        kp_yolo.ApiKPException

        See Also
        --------
        kp.core.connect_devices : To connect multiple (including one) Kneron devices.
        kp_yolo.inference.app_yolo_inference_send : Send image for YOLO inference.
        kp_yolo.AppYoloResult
        """
        inference_number = ctypes.c_uint32()
        app_yolo_result = AppYoloResult()

        status = KPInference.__KP_WRAPPER.LIB.kp_app_yolo_inference_receive(device_group.address,
                                                                            ctypes.byref(inference_number),
                                                                            ctypes.byref(
                                                                                app_yolo_result._get_element_buffer()))

        _check_api_return_code(result=[inference_number.value, app_yolo_result],
                               api_return_code=ApiReturnCode(status))

        return inference_number.value, app_yolo_result
