# ******************************************************************************
#  Copyright (c) 2021. Kneron Inc. All rights reserved.                        *
# ******************************************************************************

from enum import Enum


class Const(Enum):
    """
    Kneron PLUS APP Yolo constant value.

    Attributes
    ----------
    APP_POST_PROC_CONFIG_DATA_SIZE : int
        Size of data containing anchor and stride array for C structure.
    """

    APP_POST_PROC_CONFIG_ANCHOR_ROW = 3
    APP_POST_PROC_CONFIG_ANCHOR_COL = 6
    APP_POST_PROC_CONFIG_STRIDE_SIZE = APP_POST_PROC_CONFIG_ANCHOR_ROW
    APP_POST_PROC_CONFIG_DATA_SIZE = 40
