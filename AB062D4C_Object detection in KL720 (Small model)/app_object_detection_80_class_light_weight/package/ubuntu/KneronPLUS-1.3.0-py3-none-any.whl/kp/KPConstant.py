# ******************************************************************************
#  Copyright (c) 2021. Kneron Inc. All rights reserved.                        *
# ******************************************************************************

from enum import Enum


class Const(Enum):
    """
    Kneron PLUS constant value.

    Attributes
    ----------
    MAX_CROP_BOX : int
        Maximum number of crop boxes.
    FD_MAX : int
        Maximum number of face detection bounding boxes.
    LAND_MARK_POINTS : int
        Number of land marks points.
    FR_FEAT_LENGTH : int
        The length of one feature map.
    YOLO_GOOD_BOX_MAX : int
        Maximum number of bounding boxes for Yolo models.
    APP_PADDING_BYTES : int
        Reserved padding bytes for C structure.
    """

    MAX_CROP_BOX = 4
    FD_MAX = 10
    LAND_MARK_POINTS = 5
    YOLO_GOOD_BOX_MAX = 100
    FR_FEAT_LENGTH = 256

    APP_PADDING_BYTES = 20
