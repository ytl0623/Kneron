# ******************************************************************************
#  Copyright (c) 2021. Kneron Inc. All rights reserved.                        *
# ******************************************************************************

from .KPValue import GenericRawImageHeader, GenericRawBypassPreProcImageHeader, ModelNefDescriptor
from typing import Union


def _get_model_raw_out_size(generic_raw_image_header: Union[GenericRawImageHeader, GenericRawBypassPreProcImageHeader],
                            model_nef_descriptor: ModelNefDescriptor) -> int:
    max_raw_out_size = -1
    for idx in range(model_nef_descriptor.num_models):
        single_model_descriptor = model_nef_descriptor.models[idx]
        if generic_raw_image_header.model_id == single_model_descriptor.id:
            max_raw_out_size = single_model_descriptor.max_raw_out_size
    return max_raw_out_size
