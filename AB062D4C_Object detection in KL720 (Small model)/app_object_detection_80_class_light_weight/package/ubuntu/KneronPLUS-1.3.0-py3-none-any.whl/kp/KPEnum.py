# ******************************************************************************
#  Copyright (c) 2021. Kneron Inc. All rights reserved.                        *
# ******************************************************************************

from enum import IntEnum


class ProductId(IntEnum):
    """
    enum for USB PID(Product ID).

    Attributes
    ----------
    KP_DEVICE_KL520 : int, default=0x100
        Product ID of KL520.
    KP_DEVICE_KL720 : int, default=0x720
        Product ID of KL720.
    """
    KP_DEVICE_KL520 = 0x100
    KP_DEVICE_KL720 = 0x720


class UsbSpeed(IntEnum):
    """
    enum for USB speed mode.

    Attributes
    ----------
    KP_USB_SPEED_UNKNOWN : int, default=0
        unknown speed.
    KP_USB_SPEED_LOW : int, default=1
        Low speed.
    KP_USB_SPEED_FULL : int, default=2
        Full speed.
    KP_USB_SPEED_HIGH : int, default=3
        High speed.
    KP_USB_SPEED_SUPER : int, default=4
        Super speed.
    """
    KP_USB_SPEED_UNKNOWN = 0
    KP_USB_SPEED_LOW = 1
    KP_USB_SPEED_FULL = 2
    KP_USB_SPEED_HIGH = 3
    KP_USB_SPEED_SUPER = 4


class ResetMode(IntEnum):
    """
    enum for reset mode.

    Attributes
    ----------
    KP_RESET_REBOOT : int, default=0
        Higheset level to reset Kneron device. Kneron device would disconnect after this reset.
    KP_RESET_INFERENCE : int, default=1
        Soft reset - reset inference FIFO queue.
    KP_RESET_SHUTDOWN : int, default=2
        Shut down Kneron device. For KL520, only useful if HW circuit supports (ex. 96 bord), dongle is not supported. For KL720, this function is not supported.
    """
    KP_RESET_REBOOT = 0
    KP_RESET_INFERENCE = 1
    KP_RESET_SHUTDOWN = 2


class ChannelOrdering(IntEnum):
    """
    enum for feature map channels ordering.

    Attributes
    ----------
    KP_CHANNEL_ORDERING_HCW : int, default=0
        KL520 default, height/channel/width in order.
    KP_CHANNEL_ORDERING_CHW : int, default=1
        KL720 default, channel/height/width in order.
    """
    KP_CHANNEL_ORDERING_HCW = 0
    KP_CHANNEL_ORDERING_CHW = 1


class ImageFormat(IntEnum):
    """
    enum for image format supported for inference.

    Attributes
    ----------
    KP_IMAGE_FORMAT_UNKNOWN : int, default=0x0
        Unknown format.
    KP_IMAGE_FORMAT_RGB565 : int, default=0x60
        RGB565 16bits.
    KP_IMAGE_FORMAT_RGBA8888 : int, default=0x0D
        RGBA8888 32bits.
    KP_IMAGE_FORMAT_YUYV : int, default=0x2F
        YUYV 16bits.
    KP_IMAGE_FORMAT_YCBCR422_CRY1CBY0 : int, default=0x30
        YCbCr422 16bit (order: CrY1CbY0).
    KP_IMAGE_FORMAT_YCBCR422_CBY1CRY0 : int, default=0x31
        YCbCr422 16bit (order: CbY1CrY0).
    KP_IMAGE_FORMAT_YCBCR422_Y1CRY0CB : int, default=0x32
        YCbCr422 16bit (order: Y1CrY0Cb).
    KP_IMAGE_FORMAT_YCBCR422_Y1CBY0CR : int, default=0x33
        YCbCr422 16bit (order: Y1CbY0Cr).
    KP_IMAGE_FORMAT_YCBCR422_CRY0CBY1 : int, default=0x34
        YCbCr422 16bit (order: CrY0CbY1).
    KP_IMAGE_FORMAT_YCBCR422_CBY0CRY1 : int, default=0x35
        YCbCr422 16bit (order: CbY0CrY1).
    KP_IMAGE_FORMAT_YCBCR422_Y0CRY1CB : int, default=0x36
        YCbCr422 16bit (order: Y0CrY1Cb).
    KP_IMAGE_FORMAT_YCBCR422_Y0CBY1CR : int, default=0x37
        YCbCr422 16bit (order: Y0CbY1Cr).
    KP_IMAGE_FORMAT_RAW8 : int, default=0x20
        RAW 8bits (Grayscale).
    """
    KP_IMAGE_FORMAT_UNKNOWN = 0x0
    KP_IMAGE_FORMAT_RGB565 = 0x60
    KP_IMAGE_FORMAT_RGBA8888 = 0x0D
    KP_IMAGE_FORMAT_YUYV = 0x2F
    KP_IMAGE_FORMAT_YCBCR422_CRY1CBY0 = 0x30
    KP_IMAGE_FORMAT_YCBCR422_CBY1CRY0 = 0x31
    KP_IMAGE_FORMAT_YCBCR422_Y1CRY0CB = 0x32
    KP_IMAGE_FORMAT_YCBCR422_Y1CBY0CR = 0x33
    KP_IMAGE_FORMAT_YCBCR422_CRY0CBY1 = 0x34
    KP_IMAGE_FORMAT_YCBCR422_CBY0CRY1 = 0x35
    KP_IMAGE_FORMAT_YCBCR422_Y0CRY1CB = 0x36
    KP_IMAGE_FORMAT_YCBCR422_Y0CBY1CR = 0x37
    KP_IMAGE_FORMAT_RAW8 = 0x20


class NormalizeMode(IntEnum):
    """
    enum for normalization mode

    Attributes
    ----------
    KP_NORMALIZE_DISABLE : int, default=0xFF
        Disable normalize.
    KP_NORMALIZE_KNERON : int, default=0x1
        RGB/256 - 0.5, refer to the toolchain manual.
    KP_NORMALIZE_TENSOR_FLOW : int, default=0x2
        RGB/127.5 - 1.0, refer to the toolchain manual.
    KP_NORMALIZE_YOLO : int, default=0x3
        RGB/255.0, refer to the toolchain manual.
    KP_NORMALIZE_CUSTOMIZED_DEFAULT : int, default=0x4
        customized, default, refer to the toolchain manual.
    KP_NORMALIZE_CUSTOMIZED_SUB128 : int, default=0x5
        customized, subtract 128, refer to the toolchain manual.
    KP_NORMALIZE_CUSTOMIZED_DIV2 : int, default=0x6
        customized, divide by 2, refer to the toolchain manual.
    KP_NORMALIZE_CUSTOMIZED_SUB128_DIV2 : int, default=0x7
        customized, subtract 128 and divide by 2, refer to the toolchain manual.

    See Also
    --------
    Toolchain manual - http://doc.kneron.com/docs/#toolchain/manual/.
    """
    KP_NORMALIZE_DISABLE = 0xFF
    KP_NORMALIZE_KNERON = 0x1
    KP_NORMALIZE_TENSOR_FLOW = 0x2
    KP_NORMALIZE_YOLO = 0x3
    KP_NORMALIZE_CUSTOMIZED_DEFAULT = 0x4
    KP_NORMALIZE_CUSTOMIZED_SUB128 = 0x5
    KP_NORMALIZE_CUSTOMIZED_DIV2 = 0x6
    KP_NORMALIZE_CUSTOMIZED_SUB128_DIV2 = 0x7


class ResizeMode(IntEnum):
    """
    enum for resize mode

    Attributes
    ----------
    KP_RESIZE_DISABLE : int, default=0x1
        Disable resize in pre-process.
    KP_RESIZE_ENABLE : int, default=0x2
        Enable resize in pre-process.
    """
    KP_RESIZE_DISABLE = 0x1
    KP_RESIZE_ENABLE = 0x2


class PaddingMode(IntEnum):
    """
    enum for padding mode

    Attributes
    ----------
    KP_PADDING_DISABLE : int, default=0x1
        Disable padding in pre-process.
    KP_PADDING_CORNER : int, default=0x2
        Enable corner padding (padding right and bottom) in pre-process.
    KP_PADDING_SYMMETRIC : int, default=0x3
        Enable symmetric padding (padding right, left, top and bottom) in pre-process.
    """
    KP_PADDING_DISABLE = 0x1
    KP_PADDING_CORNER = 0x2
    KP_PADDING_SYMMETRIC = 0x3


class ApiReturnCode(IntEnum):
    """
    Return code of PLUS APIs.

    Attributes
    ----------
    KP_SUCCESS : int, default=0

    KP_ERROR_USB_IO_N1 : int, default=-1
    KP_ERROR_USB_INVALID_PARAM_N2 : int, default=-2
    KP_ERROR_USB_ACCESS_N3 : int, default=-3
    KP_ERROR_USB_NO_DEVICE_N4 : int, default=-4
    KP_ERROR_USB_NOT_FOUND_N5 : int, default=-5
    KP_ERROR_USB_BUSY_N6 : int, default=-6
    KP_ERROR_USB_TIMEOUT_N7 : int, default=-7
    KP_ERROR_USB_OVERFLOW_N8 : int, default=-8
    KP_ERROR_USB_PIPE_N9 : int, default=-9
    KP_ERROR_USB_INTERRUPTED_N10 : int, default=-10
    KP_ERROR_USB_NO_MEM_N11 : int, default=-11
    KP_ERROR_USB_NOT_SUPPORTED_N12 : int, default=-12
    KP_ERROR_USB_OTHER_N99 : int, default=-99

    KP_ERROR_DEVICE_NOT_EXIST_10 : int, default=10
    KP_ERROR_DEVICE_INCORRECT_RESPONSE_11 : int, default=11
    KP_ERROR_INVALID_PARAM_12 : int, default=12
    KP_ERROR_SEND_DESC_FAIL_13 : int, default=13
    KP_ERROR_SEND_DATA_FAIL_14 : int, default=14
    KP_ERROR_SEND_DATA_TOO_LARGE_15 : int, default=15
    KP_ERROR_RECV_DESC_FAIL_16 : int, default=16
    KP_ERROR_RECV_DATA_FAIL_17 : int, default=17
    KP_ERROR_RECV_DATA_TOO_LARGE_18 : int, default=18
    KP_ERROR_FW_UPDATE_FAILED_19 : int, default=19
    KP_ERROR_FILE_OPEN_FAILED_20 : int, default=20
    KP_ERROR_INVALID_MODEL_21 : int, default=21
    KP_ERROR_IMAGE_RESOLUTION_TOO_SMALL_22 : int, default=22
    KP_ERROR_IMAGE_ODD_WIDTH_23 : int, default=23
    KP_ERROR_INVALID_FIRMWARE_24 : int, default=24
    KP_ERROR_RESET_FAILED_25 : int, default=25
    KP_ERROR_DEVICES_NUMBER_26 : int, default=26
    KP_ERROR_CONFIGURE_DEVICE_27 : int, default=27
    KP_ERROR_CONNECT_FAILED_28 : int, default=28
    KP_ERROR_DEVICE_GROUP_MIX_PRODUCT_29 : int, default=29
    KP_ERROR_RECEIVE_INCORRECT_HEADER_STAMP_30 : int, default=30
    KP_ERROR_RECEIVE_SIZE_MISMATCH_31 : int, default=31
    KP_ERROR_RECEIVE_JOB_ID_MISMATCH_32 : int, default=32
    KP_ERROR_INVALID_CUSTOMIZED_JOB_ID_33 : int, default=33
    KP_ERROR_FW_LOAD_FAILED_34 : int, default=34
    KP_ERROR_MODEL_NOT_LOADED_35 : int, default=35

    KP_ERROR_OTHER_99 : int, default=99

    KP_FW_ERROR_UNKNOWN_APP : int, default=100
    KP_FW_INFERENCE_ERROR_101 : int, default=101
    KP_FW_DDR_MALLOC_FAILED_102 : int, default=102
    KP_FW_INFERENCE_TIMEOUT_103 : int, default=103
    KP_FW_LOAD_MODEL_FAILED_104 : int, default=104
    KP_FW_CONFIG_POST_PROC_ERROR_MALLOC_FAILED_105 : int, default=105
    KP_FW_CONFIG_POST_PROC_ERROR_NO_SPACE_106 : int, default=106
    KP_FW_IMAGE_SIZE_NOT_MATCH_MODEL_INPUT_107 : int, default=107
    KP_FW_NOT_SUPPORT_PREPROCESSING_108 : int, default=108

    KP_FW_NCPU_ERR_BEGIN : int, default=200
    KP_FW_NCPU_INVALID_IMAGE_201 : int, default=201

    KP_FW_EFUSE_CAN_NOT_BURN : int, default=300
    KP_FW_EFUSE_PROTECTED : int, default=301
    KP_FW_EFUSE_OTHER : int, default=302
    """
    KP_SUCCESS = 0

    # libusb error code
    KP_ERROR_USB_IO_N1 = -1
    KP_ERROR_USB_INVALID_PARAM_N2 = -2
    KP_ERROR_USB_ACCESS_N3 = -3
    KP_ERROR_USB_NO_DEVICE_N4 = -4
    KP_ERROR_USB_NOT_FOUND_N5 = -5
    KP_ERROR_USB_BUSY_N6 = -6
    KP_ERROR_USB_TIMEOUT_N7 = -7
    KP_ERROR_USB_OVERFLOW_N8 = -8
    KP_ERROR_USB_PIPE_N9 = -9
    KP_ERROR_USB_INTERRUPTED_N10 = -10
    KP_ERROR_USB_NO_MEM_N11 = -11
    KP_ERROR_USB_NOT_SUPPORTED_N12 = -12
    KP_ERROR_USB_OTHER_N99 = -99

    # host error code
    KP_ERROR_DEVICE_NOT_EXIST_10 = 10
    KP_ERROR_DEVICE_INCORRECT_RESPONSE_11 = 11
    KP_ERROR_INVALID_PARAM_12 = 12
    KP_ERROR_SEND_DESC_FAIL_13 = 13
    KP_ERROR_SEND_DATA_FAIL_14 = 14
    KP_ERROR_SEND_DATA_TOO_LARGE_15 = 15
    KP_ERROR_RECV_DESC_FAIL_16 = 16
    KP_ERROR_RECV_DATA_FAIL_17 = 17
    KP_ERROR_RECV_DATA_TOO_LARGE_18 = 18
    KP_ERROR_FW_UPDATE_FAILED_19 = 19
    KP_ERROR_FILE_OPEN_FAILED_20 = 20
    KP_ERROR_INVALID_MODEL_21 = 21
    KP_ERROR_IMAGE_RESOLUTION_TOO_SMALL_22 = 22
    KP_ERROR_IMAGE_ODD_WIDTH_23 = 23
    KP_ERROR_INVALID_FIRMWARE_24 = 24
    KP_ERROR_RESET_FAILED_25 = 25
    KP_ERROR_DEVICES_NUMBER_26 = 26
    KP_ERROR_CONFIGURE_DEVICE_27 = 27
    KP_ERROR_CONNECT_FAILED_28 = 28
    KP_ERROR_DEVICE_GROUP_MIX_PRODUCT_29 = 29
    KP_ERROR_RECEIVE_INCORRECT_HEADER_STAMP_30 = 30
    KP_ERROR_RECEIVE_SIZE_MISMATCH_31 = 31
    KP_ERROR_RECEIVE_JOB_ID_MISMATCH_32 = 32
    KP_ERROR_INVALID_CUSTOMIZED_JOB_ID_33 = 33
    KP_ERROR_FW_LOAD_FAILED_34 = 34
    KP_ERROR_MODEL_NOT_LOADED_35 = 35

    KP_ERROR_OTHER_99 = 99

    # firmware error code
    KP_FW_ERROR_UNKNOWN_APP = 100
    KP_FW_INFERENCE_ERROR_101 = 101
    KP_FW_DDR_MALLOC_FAILED_102 = 102
    KP_FW_INFERENCE_TIMEOUT_103 = 103
    KP_FW_LOAD_MODEL_FAILED_104 = 104
    KP_FW_CONFIG_POST_PROC_ERROR_MALLOC_FAILED_105 = 105
    KP_FW_CONFIG_POST_PROC_ERROR_NO_SPACE_106 = 106
    KP_FW_IMAGE_SIZE_NOT_MATCH_MODEL_INPUT_107 = 107
    KP_FW_NOT_SUPPORT_PREPROCESSING_108 = 108

    # ncpu error code (sync with ipc.h)
    KP_FW_NCPU_ERR_BEGIN = 200
    KP_FW_NCPU_INVALID_IMAGE_201 = 201

    # firmware eFuse error code
    KP_FW_EFUSE_CAN_NOT_BURN = 300
    KP_FW_EFUSE_PROTECTED = 301
    KP_FW_EFUSE_OTHER = 302
