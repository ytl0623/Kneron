# ******************************************************************************
#  Copyright (c) 2021. Kneron Inc. All rights reserved.                        *
# ******************************************************************************

from .KPBaseClass.StructureBase import BufferBase
from .KPEnum import *
from .KPConstant import Const
from typing import List
import ctypes
import numpy as np


class DeviceDescriptorBuffer(BufferBase):
    """DeviceDescriptor structure"""
    _pack_ = 4
    _fields_ = [('_port_id', ctypes.c_uint32),
                ('_vendor_id', ctypes.c_uint16),
                ('_product_id', ctypes.c_uint16),
                ('_link_speed', ctypes.c_int),
                ('_kn_number', ctypes.c_uint32),
                ('_isConnectable', ctypes.c_bool),
                ('_port_path', ctypes.c_char * 20),
                ('_firmware', ctypes.c_char * 30)]

    def _init_buffer(self,
                     usb_port_id: int = 0,
                     vendor_id: int = 0,
                     product_id: int = 0,
                     link_speed: UsbSpeed = UsbSpeed.KP_USB_SPEED_UNKNOWN,
                     kn_number: int = 0,
                     is_connectable: bool = False,
                     usb_port_path: str = '',
                     firmware: str = '') -> None:
        assert 20 >= len(usb_port_path)
        assert 30 >= len(firmware)

        self._port_id = usb_port_id
        self._vendor_id = vendor_id
        self._product_id = product_id
        self._link_speed = link_speed.value
        self._kn_number = kn_number
        self._isConnectable = is_connectable
        self._port_path = usb_port_path.encode('utf-8')
        self._firmware = firmware.encode('utf-8')


class DeviceDescriptorListBuffer(BufferBase):
    """DeviceDescriptorList structure"""
    _pack_ = 4
    _fields_ = [('_num_dev', ctypes.c_int),
                ('_device', ctypes.POINTER(DeviceDescriptorBuffer))]

    def __init__(self, device_descriptor_buffer_list: List[DeviceDescriptorBuffer] = []):
        """ check if allocated memory from c """
        self._init_buffer(device_descriptor_buffer_list=device_descriptor_buffer_list)

    def _init_buffer(self, device_descriptor_buffer_list: List[DeviceDescriptorBuffer] = []) -> None:
        self._num_dev = len(device_descriptor_buffer_list)
        self.__device_c_array = (DeviceDescriptorBuffer * self._num_dev)(*device_descriptor_buffer_list)
        self._device = ctypes.cast(self.__device_c_array, ctypes.POINTER(DeviceDescriptorBuffer))


class DeviceGroupBuffer(BufferBase):
    """DeviceGroupBuffer structure"""
    _pack_ = 4
    _fields_ = [('_address', ctypes.c_void_p)]

    def __init__(self, address: int):
        """ check if allocated memory from c """
        self._init_buffer(address=address)

    def _init_buffer(self, address: int) -> None:
        self._address = ctypes.c_void_p(address)


class SingleModelDescriptorBuffer(BufferBase):
    """SingleModelDescriptor structure"""
    _pack_ = 4
    _fields_ = [('_id', ctypes.c_uint32),
                ('_max_raw_out_size', ctypes.c_uint32),
                ('_width', ctypes.c_uint32),
                ('_height', ctypes.c_uint32),
                ('_channel', ctypes.c_uint32),
                ('_img_format', ctypes.c_uint32)]

    def _init_buffer(self,
                     id: int = 0,
                     max_raw_out_size: int = 0,
                     width: int = 0,
                     height: int = 0,
                     channel: int = 0,
                     img_format: ImageFormat = ImageFormat.KP_IMAGE_FORMAT_RGBA8888) -> None:
        assert 0 <= max_raw_out_size
        assert 0 <= width
        assert 0 <= height
        assert 0 <= channel
        assert 0 <= img_format.value

        self._id = id
        self._max_raw_out_size = max_raw_out_size
        self._width = width
        self._height = height
        self._channel = channel
        self._img_format = img_format.value


class ModelNefDescriptorBuffer(BufferBase):
    """ModelNefDescriptor List structure"""
    _pack_ = 4
    _fields_ = [('_crc', ctypes.c_uint32),
                ('_num_models', ctypes.c_int),
                ('_models', SingleModelDescriptorBuffer * 10)]

    def _init_buffer(self,
                     crc: int = 0,
                     num_models: int = 0,
                     models: List[SingleModelDescriptorBuffer] = []) -> None:
        assert 0 <= crc
        assert 0 <= num_models

        self._crc = crc
        self._num_models = num_models
        self._models = (SingleModelDescriptorBuffer * 10)(*models)


class FirmwareVersionBuffer(BufferBase):
    """FirmwareVersion structure"""
    _pack_ = 4
    _fields_ = [('_reserved', ctypes.c_uint8),
                ('_major', ctypes.c_uint8),
                ('_minor', ctypes.c_uint8),
                ('_update', ctypes.c_uint8),
                ('_build', ctypes.c_uint32)]

    def _init_buffer(self,
                     reserved: int = 0,
                     major: int = 0,
                     minor: int = 0,
                     update: int = 0,
                     build: int = 0) -> None:
        assert 0 <= reserved
        assert 0 <= major
        assert 0 <= minor
        assert 0 <= update
        assert 0 <= build

        self._reserved = reserved
        self._major = major
        self._minor = minor
        self._update = update
        self._build = build


class SystemInfoBuffer(BufferBase):
    """SystemInfo structure"""
    _pack_ = 4
    _fields_ = [('_kn_number', ctypes.c_uint32),
                ('_firmware_version', FirmwareVersionBuffer)]

    def _init_buffer(self,
                     kn_number: int = 0,
                     firmware_version: FirmwareVersionBuffer = FirmwareVersionBuffer()) -> None:
        assert 0 <= kn_number

        self._kn_number = kn_number
        self._firmware_version = firmware_version


class InfConfigurationBuffer(BufferBase):
    """InfConfiguration structure"""
    _pack_ = 4
    _fields_ = [('_enable_frame_drop', ctypes.c_bool)]

    def _init_buffer(self,
                     enable_frame_drop: bool = False) -> None:
        self._enable_frame_drop = enable_frame_drop


class InfCropBoxBuffer(BufferBase):
    """InfCropBox structure"""
    _pack_ = 4
    _fields_ = [('_crop_number', ctypes.c_uint32),
                ('_x1', ctypes.c_uint32),
                ('_y1', ctypes.c_uint32),
                ('_width', ctypes.c_uint32),
                ('_height', ctypes.c_uint32)]

    def _init_buffer(self,
                     crop_box_index: int = 0,
                     x: int = 0,
                     y: int = 0,
                     width: int = 0,
                     height: int = 0) -> None:
        assert 0 <= crop_box_index
        assert 0 <= x
        assert 0 <= y
        assert 0 <= width
        assert 0 <= height

        self._crop_number = crop_box_index
        self._x1 = x
        self._y1 = y
        self._width = width
        self._height = height


class GenericRawImageHeaderBuffer(BufferBase):
    """GenericRawImageHeader structure"""
    _pack_ = 4
    _fields_ = [('_inference_number', ctypes.c_uint32),
                ('_width', ctypes.c_uint32),
                ('_height', ctypes.c_uint32),
                ('_resize_mode', ctypes.c_uint32),
                ('_padding_mode', ctypes.c_uint32),
                ('_image_format', ctypes.c_uint32),
                ('_normalize_mode', ctypes.c_uint32),
                ('_model_id', ctypes.c_uint32),
                ('_crop_count', ctypes.c_uint32),
                ('_inf_crop', InfCropBoxBuffer * Const.MAX_CROP_BOX.value)]

    def _init_buffer(self,
                     width: int = 0,
                     height: int = 0,
                     resize_mode: ResizeMode = ResizeMode.KP_RESIZE_ENABLE,
                     padding_mode: PaddingMode = PaddingMode.KP_PADDING_CORNER,
                     image_format: ImageFormat = ImageFormat.KP_IMAGE_FORMAT_RGB565,
                     normalize_mode: NormalizeMode = NormalizeMode.KP_NORMALIZE_KNERON,
                     inference_number: int = 0,
                     model_id: int = 0,
                     inference_crop_box_buffer_list: List[InfCropBoxBuffer] = []) -> None:
        assert 0 <= width
        assert 0 <= height
        assert 0 <= inference_number
        assert 0 <= model_id

        self._width = width
        self._height = height
        self._resize_mode = resize_mode.value
        self._padding_mode = padding_mode.value
        self._image_format = image_format.value
        self._normalize_mode = normalize_mode.value
        self._inference_number = inference_number
        self._model_id = model_id
        self._crop_count = len(inference_crop_box_buffer_list)
        self._inf_crop = (InfCropBoxBuffer * Const.MAX_CROP_BOX.value)(*inference_crop_box_buffer_list)


class GenericRawResultNDArrayBuffer(BufferBase):
    """GenericRawResultNDArray structure"""
    _pack_ = 4
    _fields_ = [('_LP_raw_out_buffer', ctypes.POINTER(ctypes.c_uint8))]

    def _init_buffer(self, buffer_size: int = 0) -> None:
        self._buffer_size = buffer_size
        self._LP_raw_out_buffer = ctypes.cast((ctypes.c_uint8 * buffer_size)(),
                                              ctypes.POINTER(ctypes.c_uint8))


class GenericRawResultHeaderBuffer(BufferBase):
    """GenericRawResultHeader structure"""
    _pack_ = 4
    _fields_ = [('_inference_number', ctypes.c_uint32),
                ('_crop_number', ctypes.c_uint32),
                ('_num_output_node', ctypes.c_uint32)]

    def _init_buffer(self,
                     inference_number: int = 0,
                     crop_number: int = 0,
                     num_output_node: int = 0) -> None:
        assert 0 <= inference_number
        assert 0 <= crop_number
        assert 0 <= num_output_node

        self._inference_number = inference_number
        self._crop_number = crop_number
        self._num_output_node = num_output_node


class GenericRawBypassPreProcImageHeaderBuffer(BufferBase):
    """GenericRawBypassPreProcImageHeader structure"""
    _pack_ = 4
    _fields_ = [('_inference_number', ctypes.c_uint32),
                ('_image_buffer_size', ctypes.c_uint32),
                ('_model_id', ctypes.c_uint32)]

    def _init_buffer(self,
                     inference_number: int = 0,
                     image_buffer_size: int = 0,
                     model_id: int = 0) -> None:
        assert 0 <= inference_number
        assert 0 <= image_buffer_size
        assert 0 <= model_id

        self._inference_number = inference_number
        self._image_buffer_size = image_buffer_size
        self._model_id = model_id


class GenericRawBypassPreProcResultHeaderBuffer(BufferBase):
    """GenericRawBypassPreProcResultHeader structure"""
    _pack_ = 4
    _fields_ = [('_inference_number', ctypes.c_uint32),
                ('_crop_number', ctypes.c_uint32),
                ('_num_output_node', ctypes.c_uint32)]

    def _init_buffer(self,
                     inference_number: int = 0,
                     crop_number: int = 0,
                     num_output_node: int = 0) -> None:
        assert 0 <= inference_number
        assert 0 <= crop_number
        assert 0 <= num_output_node

        self._inference_number = inference_number
        self._crop_number = crop_number
        self._num_output_node = num_output_node


class InfFixedNodeOutputBuffer(BufferBase):
    """InfFixedNodeOutputBuffer structure"""
    _pack_ = 4
    _fields_ = [('_width', ctypes.c_uint32),
                ('_height', ctypes.c_uint32),
                ('_channel', ctypes.c_uint32),
                ('_radix', ctypes.c_int32),
                ('_scale', ctypes.c_float),
                ('_factor', ctypes.c_float),
                ('_num_data', ctypes.c_uint32),
                ('_data', ctypes.POINTER(ctypes.c_float))]

    def _init_buffer(self,
                     width: int = 0,
                     height: int = 0,
                     channel: int = 0,
                     radix: int = 0,
                     scale: float = 0,
                     factor: float = 0,
                     num_data: int = 0,
                     data: np.ndarray = np.array([])) -> None:
        assert 0 <= width
        assert 0 <= height
        assert 0 <= channel
        assert 0 <= num_data

        self._width = width
        self._height = height
        self._channel = channel
        self._radix = radix
        self._scale = scale
        self._factor = factor
        self._num_data = num_data
        self._data = data.ctypes.data_as(ctypes.POINTER(ctypes.c_float))


class InfFloatNodeOutputBuffer(BufferBase):
    """InfFloatNodeOutputBuffer structure"""
    _pack_ = 4
    _fields_ = [('_width', ctypes.c_uint32),
                ('_height', ctypes.c_uint32),
                ('_channel', ctypes.c_uint32),
                ('_num_data', ctypes.c_uint32),
                ('_data', ctypes.POINTER(ctypes.c_float))]

    def _init_buffer(self,
                     width: int = 0,
                     height: int = 0,
                     channel: int = 0,
                     num_data: int = 0,
                     data: np.ndarray = np.array([])) -> None:
        assert 0 <= width
        assert 0 <= height
        assert 0 <= channel
        assert 0 <= num_data

        self._width = width
        self._height = height
        self._channel = channel
        self._num_data = num_data
        self._data = data.ctypes.data_as(ctypes.POINTER(ctypes.c_float))


class BoundingBoxBuffer(BufferBase):
    """BoundingBoxBuffer structure"""
    _pack_ = 4
    _fields_ = [('_x1', ctypes.c_float),
                ('_y1', ctypes.c_float),
                ('_x2', ctypes.c_float),
                ('_y2', ctypes.c_float),
                ('_score', ctypes.c_float),
                ('_class_num', ctypes.c_int32)]

    def _init_buffer(self,
                     x1: float = 0,
                     y1: float = 0,
                     x2: float = 0,
                     y2: float = 0,
                     score: float = 0,
                     class_num: int = 0) -> None:
        assert 0 <= x1
        assert 0 <= y1
        assert 0 <= x2
        assert 0 <= y2

        self._x1 = x1
        self._y1 = y1
        self._x2 = x2
        self._y2 = y2
        self._score = score
        self._class_num = class_num


class PointBuffer(BufferBase):
    """PointBuffer structure"""
    _pack_ = 4
    _fields_ = [('_x', ctypes.c_uint32),
                ('_y', ctypes.c_uint32)]

    def _init_buffer(self,
                     x: float = 0,
                     y: float = 0, ) -> None:
        assert 0 <= x
        assert 0 <= y

        self._x = x
        self._y = y


class LandMarkBuffer(BufferBase):
    """LandMarkBuffer structure"""
    _pack_ = 4
    _fields_ = [('_marks', PointBuffer * Const.LAND_MARK_POINTS.value),
                ('_score', ctypes.c_float),
                ('_blur', ctypes.c_float),
                ('_class_num', ctypes.c_int32)]

    def _init_buffer(self,
                     point_list: List[PointBuffer] = [],
                     score: float = 0,
                     blur: float = 0,
                     class_num: int = 0) -> None:
        self._marks = (PointBuffer * Const.LAND_MARK_POINTS.value)(*point_list)
        self._score = score
        self._blur = blur
        self._class_num = class_num


class ClassificationBuffer(BufferBase):
    """ClassificationBuffer structure"""
    _pack_ = 4
    _fields_ = [('_class_num', ctypes.c_uint32),
                ('_score', ctypes.c_float)]

    def _init_buffer(self,
                     class_num: int = 0,
                     score: float = 0) -> None:
        self._class_num = class_num
        self._score = score


class FaceRecognizeBuffer(BufferBase):
    """FaceRecognizeBuffer structure"""
    _pack_ = 4
    _fields_ = [('_feature_map', ctypes.c_float * Const.FR_FEAT_LENGTH.value),
                ('_feature_map_fixed', ctypes.c_int8 * Const.FR_FEAT_LENGTH.value)]

    def _init_buffer(self,
                     feature_map: np.ndarray = np.zeros((Const.FR_FEAT_LENGTH.value,), dtype=np.float32),
                     feature_map_fixed: np.ndarray = np.zeros((Const.FR_FEAT_LENGTH.value,), dtype=np.int8)):
        assert feature_map.shape[0] == Const.FR_FEAT_LENGTH.value
        assert feature_map_fixed.shape[0] == Const.FR_FEAT_LENGTH.value

        self._feature_map = np.ctypeslib.as_ctypes(feature_map.reshape(-1))
        self._feature_map_fixed = np.ctypeslib.as_ctypes(feature_map_fixed.reshape(-1))
