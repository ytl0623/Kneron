# ******************************************************************************
#  Copyright (c) 2021. Kneron Inc. All rights reserved.                        *
# ******************************************************************************

# from KP
from kp.KPBaseClass.LibLoaderBase import LibLoaderBase


class KPLibLoader(LibLoaderBase):
    def __init__(self):
        super(KPLibLoader, self).__init__(package_name='kp_yolo')

    def _init_kneron_libs(self):
        self._kneron_libs = [
            'libkapp_yolo.{}'.format(LibLoaderBase.EXTENSION_FLAG)
        ]

    def _init_share_libs_load_order(self):
        self._share_libs_load_order = [
            'libkapp_yolo.{}'.format(LibLoaderBase.EXTENSION_FLAG)
        ]
