# ******************************************************************************
#  Copyright (c) 2021-2022. Kneron Inc. All rights reserved.                   *
# ******************************************************************************

from .KPValue import DeviceGroup
from .KPWrapper import KPWrapper
from .KPEnum import ApiReturnCode
from .KPException import _check_api_return_code


class KPPeripheral:
    @staticmethod
    def set_customize_key(device_group: DeviceGroup,
                          customize_key: int) -> None:
        """
        (Advance) Set customize key of Kneron device through USB.

        Parameters
        ----------
        device_group : kp.DeviceGroup
            A set of devices handle.
        customize_key : int
            value for customize key setting.

        Raises
        ------
        kp.ApiKPException

        See Also
        --------
        kp.core.connect_devices : To connect multiple (including one) Kneron devices.
        """
        assert customize_key >= 0

        status = KPWrapper().LIB.kp_set_ckey(device_group.address, customize_key)

        _check_api_return_code(result=None,
                               api_return_code=ApiReturnCode(status))

    @staticmethod
    def set_secure_boot_key(device_group: DeviceGroup,
                            entry: int,
                            key: int) -> None:
        """
        (Advance) (KL720 Only) Set secure-boot key of Kneron device through USB.

        Parameters
        ----------
        device_group : kp.DeviceGroup
            A set of devices handle.
        entry : int
            Secure-boot key offset (range from 0 to 13).
        key : int
            value for key setting.

        Raises
        ------
        kp.ApiKPException

        See Also
        --------
        kp.core.connect_devices : To connect multiple (including one) Kneron devices.
        """
        assert 13 >= entry >= 0
        assert key >= 0

        status = KPWrapper().LIB.kp_set_secure_boot_key(device_group.address, entry, key)

        _check_api_return_code(result=None,
                               api_return_code=ApiReturnCode(status))

    @staticmethod
    def set_gpio(device_group: DeviceGroup,
                 pin: int,
                 value: int) -> None:
        """
        (Advance) (KL720 Only) Set GPIO of Kneron device through USB.

        Parameters
        ----------
        device_group : kp.DeviceGroup
            A set of devices handle.
        pin : int
            GPIO pin index (range from 0 to 31).
        value : int
            value for pin setting (zero: off, non-zero: on).

        Raises
        ------
        kp.ApiKPException

        See Also
        --------
        kp.core.connect_devices : To connect multiple (including one) Kneron devices.
        """
        assert 31 >= pin >= 0
        assert value >= 0

        status = KPWrapper().LIB.kp_set_gpio(device_group.address, pin, value)

        _check_api_return_code(result=None,
                               api_return_code=ApiReturnCode(status))
