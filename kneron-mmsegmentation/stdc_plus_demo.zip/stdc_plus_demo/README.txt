
Python libs requirement:
	1. Kneron plus v0.13.0
	2. Numpy
	3. OpenCV-Python



How to run this example:

	python KL720DemoGenericInferenceSTDC_BypassHwPreProc.py -nef ./example_stdc_720.nef -img 000000000641.jpg