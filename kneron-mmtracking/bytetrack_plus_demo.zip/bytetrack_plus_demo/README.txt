
Python libs requirement:
	1. Kneron plus v0.13.0
	2. Numpy
	3. OpenCV-Python
        4. Scipy



How to run this example:

	python KL720DemoGenericInferenceByteTrack_BypassHwPreProc.py -nef ./example_bytetrack_720.nef -vid ./MOT16-03_trim.mp4