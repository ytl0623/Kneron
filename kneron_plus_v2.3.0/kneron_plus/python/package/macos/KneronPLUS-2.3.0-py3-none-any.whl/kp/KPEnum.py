# ******************************************************************************
#  Copyright (c) 2021-2022. Kneron Inc. All rights reserved.                   *
# ******************************************************************************

from .KPBaseClass.EnumBase import BaseIntEnum


class ProductId(BaseIntEnum):
    """
    enum for USB PID(Product ID).

    Attributes
    ----------
    KP_DEVICE_KL520 : int, default=0x100
        Product ID of KL520.
    KP_DEVICE_KL720 : int, default=0x720
        Product ID of KL720.
    KP_DEVICE_KL720_LEGACY : int, default=0x200
        Legacy Product ID of KL720.
    KP_DEVICE_KL530 : int, default=0x530
        Product ID of KL530.
    KP_DEVICE_KL830 : int, default=0x832
        Product ID of KL830.
    KP_DEVICE_KL730 : int, default=0x732
        Product ID of KL730.
    KP_DEVICE_KL630 : int, default=0x630
        Product ID of KL630.
    KP_DEVICE_KL540 : int, default=0x540
        Product ID of KL540.
    """
    KP_DEVICE_KL520 = 0x100
    KP_DEVICE_KL720 = 0x720
    KP_DEVICE_KL720_LEGACY = 0x200
    KP_DEVICE_KL530 = 0x530
    KP_DEVICE_KL830 = 0x832
    KP_DEVICE_KL730 = 0x732
    KP_DEVICE_KL630 = 0x630
    KP_DEVICE_KL540 = 0x540


class UsbSpeed(BaseIntEnum):
    """
    enum for USB speed mode.

    Attributes
    ----------
    KP_USB_SPEED_UNKNOWN : int, default=0
        unknown speed.
    KP_USB_SPEED_LOW : int, default=1
        Low speed.
    KP_USB_SPEED_FULL : int, default=2
        Full speed.
    KP_USB_SPEED_HIGH : int, default=3
        High speed.
    KP_USB_SPEED_SUPER : int, default=4
        Super speed.
    """
    KP_USB_SPEED_UNKNOWN = 0
    KP_USB_SPEED_LOW = 1
    KP_USB_SPEED_FULL = 2
    KP_USB_SPEED_HIGH = 3
    KP_USB_SPEED_SUPER = 4


class ResetMode(BaseIntEnum):
    """
    enum for reset mode.

    Attributes
    ----------
    KP_RESET_REBOOT : int, default=0
        Higheset level to reset Kneron device. Kneron device would disconnect after this reset.
    KP_RESET_INFERENCE : int, default=1
        Soft reset - reset inference FIFO queue.
    KP_RESET_SHUTDOWN : int, default=2
        Shut down Kneron device. For KL520, only useful if HW circuit supports (ex. 96 bord), dongle is not supported. For KL720, this function is not supported.
    """
    KP_RESET_REBOOT = 0
    KP_RESET_INFERENCE = 1
    KP_RESET_SHUTDOWN = 2


class ChannelOrdering(BaseIntEnum):
    """
    enum for feature map channels ordering.

    Attributes
    ----------
    KP_CHANNEL_ORDERING_HCW : int, default=0
        KL520 default,     height/channel/width in order
    KP_CHANNEL_ORDERING_CHW : int, default=1
        KL720 default,     channel/height/width in order
    KP_CHANNEL_ORDERING_HWC : int, default=2
        TensorFlow style,  height/width/channel in order
    """
    KP_CHANNEL_ORDERING_HCW = 0
    KP_CHANNEL_ORDERING_CHW = 1
    KP_CHANNEL_ORDERING_HWC = 2


class FixedPointDType(BaseIntEnum):
    """
    enum for fixed-point data type.

    Attributes
    ----------
    KP_FIXED_POINT_DTYPE_UNKNOWN : int, default=0
        Unknown data type.
    KP_FIXED_POINT_DTYPE_INT8 : int, default=1
        Represent one fixed-point value by 8-bit data type.
    KP_FIXED_POINT_DTYPE_INT16 : int, default=2
        Represent one fixed-point value by 16-bit data type.
    """
    KP_FIXED_POINT_DTYPE_UNKNOWN = 0
    KP_FIXED_POINT_DTYPE_INT8 = 1
    KP_FIXED_POINT_DTYPE_INT16 = 2


class ImageFormat(BaseIntEnum):
    """
    enum for image format supported for inference.

    Attributes
    ----------
    KP_IMAGE_FORMAT_UNKNOWN : int, default=0x0
        Unknown format.
    KP_IMAGE_FORMAT_RGB565 : int, default=0x60
        RGB565 16bits.
    KP_IMAGE_FORMAT_RGBA8888 : int, default=0x0D
        RGBA8888 32bits.
    KP_IMAGE_FORMAT_YUYV : int, default=0x2F
        YUYV 16bits.
    KP_IMAGE_FORMAT_YCBCR422_CRY1CBY0 : int, default=0x30
        YCbCr422 16bit (order: CrY1CbY0).
    KP_IMAGE_FORMAT_YCBCR422_CBY1CRY0 : int, default=0x31
        YCbCr422 16bit (order: CbY1CrY0).
    KP_IMAGE_FORMAT_YCBCR422_Y1CRY0CB : int, default=0x32
        YCbCr422 16bit (order: Y1CrY0Cb).
    KP_IMAGE_FORMAT_YCBCR422_Y1CBY0CR : int, default=0x33
        YCbCr422 16bit (order: Y1CbY0Cr).
    KP_IMAGE_FORMAT_YCBCR422_CRY0CBY1 : int, default=0x34
        YCbCr422 16bit (order: CrY0CbY1).
    KP_IMAGE_FORMAT_YCBCR422_CBY0CRY1 : int, default=0x35
        YCbCr422 16bit (order: CbY0CrY1).
    KP_IMAGE_FORMAT_YCBCR422_Y0CRY1CB : int, default=0x36
        YCbCr422 16bit (order: Y0CrY1Cb).
    KP_IMAGE_FORMAT_YCBCR422_Y0CBY1CR : int, default=0x37
        YCbCr422 16bit (order: Y0CbY1Cr).
    KP_IMAGE_FORMAT_RAW8 : int, default=0x20
        RAW 8bits (Grayscale).
    KP_IMAGE_FORMAT_YUV420 : int, default=0x70
        YUV420 12bits (planar)
    """
    KP_IMAGE_FORMAT_UNKNOWN = 0x0
    KP_IMAGE_FORMAT_RGB565 = 0x60
    KP_IMAGE_FORMAT_RGBA8888 = 0x0D
    KP_IMAGE_FORMAT_YUYV = 0x2F
    KP_IMAGE_FORMAT_YCBCR422_CRY1CBY0 = 0x30
    KP_IMAGE_FORMAT_YCBCR422_CBY1CRY0 = 0x31
    KP_IMAGE_FORMAT_YCBCR422_Y1CRY0CB = 0x32
    KP_IMAGE_FORMAT_YCBCR422_Y1CBY0CR = 0x33
    KP_IMAGE_FORMAT_YCBCR422_CRY0CBY1 = 0x34
    KP_IMAGE_FORMAT_YCBCR422_CBY0CRY1 = 0x35
    KP_IMAGE_FORMAT_YCBCR422_Y0CRY1CB = 0x36
    KP_IMAGE_FORMAT_YCBCR422_Y0CBY1CR = 0x37
    KP_IMAGE_FORMAT_RAW8 = 0x20
    KP_IMAGE_FORMAT_YUV420 = 0x70


class NormalizeMode(BaseIntEnum):
    """
    enum for normalization mode.

    Attributes
    ----------
    KP_NORMALIZE_DISABLE : int, default=0xFF
        Disable normalize.
    KP_NORMALIZE_KNERON : int, default=0x1
        RGB/256 - 0.5, refer to the toolchain manual.
    KP_NORMALIZE_TENSOR_FLOW : int, default=0x2
        RGB/127.5 - 1.0, refer to the toolchain manual.
    KP_NORMALIZE_YOLO : int, default=0x3
        RGB/255.0, refer to the toolchain manual.
    KP_NORMALIZE_CUSTOMIZED_DEFAULT : int, default=0x4
        Customized, default, refer to the toolchain manual.
    KP_NORMALIZE_CUSTOMIZED_SUB128 : int, default=0x5
        Customized, subtract 128, refer to the toolchain manual.
    KP_NORMALIZE_CUSTOMIZED_DIV2 : int, default=0x6
        Customized, divide by 2, refer to the toolchain manual.
    KP_NORMALIZE_CUSTOMIZED_SUB128_DIV2 : int, default=0x7
        Customized, subtract 128 and divide by 2, refer to the toolchain manual.
    """
    KP_NORMALIZE_DISABLE = 0xFF
    KP_NORMALIZE_KNERON = 0x1
    KP_NORMALIZE_TENSOR_FLOW = 0x2
    KP_NORMALIZE_YOLO = 0x3
    KP_NORMALIZE_CUSTOMIZED_DEFAULT = 0x4
    KP_NORMALIZE_CUSTOMIZED_SUB128 = 0x5
    KP_NORMALIZE_CUSTOMIZED_DIV2 = 0x6
    KP_NORMALIZE_CUSTOMIZED_SUB128_DIV2 = 0x7


class ResizeMode(BaseIntEnum):
    """
    enum for resize mode.

    Attributes
    ----------
    KP_RESIZE_DISABLE : int, default=0x1
        Disable resize in pre-process.
    KP_RESIZE_ENABLE : int, default=0x2
        Enable resize in pre-process.
    """
    KP_RESIZE_DISABLE = 0x1
    KP_RESIZE_ENABLE = 0x2


class PaddingMode(BaseIntEnum):
    """
    enum for padding mode.

    Attributes
    ----------
    KP_PADDING_DISABLE : int, default=0x1
        Disable padding in pre-process.
    KP_PADDING_CORNER : int, default=0x2
        Enable corner padding (padding right and bottom) in pre-process.
    KP_PADDING_SYMMETRIC : int, default=0x3
        Enable symmetric padding (padding right, left, top and bottom) in pre-process.
    """
    KP_PADDING_DISABLE = 0x1
    KP_PADDING_CORNER = 0x2
    KP_PADDING_SYMMETRIC = 0x3


class ModelTensorDataLayout(BaseIntEnum):
    """
    enum for npu raw data layout format for tensors.

    Attributes
    ----------
    KP_MODEL_TENSOR_DATA_LAYOUT_UNKNOWN : int, default=0
        Unknown NPU data layout.
    KP_MODEL_TENSOR_DATA_LAYOUT_4W4C8B : int, default=1
        Layout - width: 4  bits, channel: 4  bits, depth: 8  bits.
    KP_MODEL_TENSOR_DATA_LAYOUT_1W16C8B : int, default=2
        Layout - width: 1  bits, channel: 16 bits, depth: 8  bits.
    KP_MODEL_TENSOR_DATA_LAYOUT_16W1C8B : int, default=3
        Layout - width: 16 bits, channel: 4  bits, depth: 8  bits.
    KP_MODEL_TENSOR_DATA_LAYOUT_8W1C16B : int, default=4
        Layout - width: 8  bits, channel: 1  bits, depth: 16 bits.
    """
    KP_MODEL_TENSOR_DATA_LAYOUT_UNKNOWN = 0
    KP_MODEL_TENSOR_DATA_LAYOUT_4W4C8B = 1
    KP_MODEL_TENSOR_DATA_LAYOUT_1W16C8B = 2
    KP_MODEL_TENSOR_DATA_LAYOUT_16W1C8B = 3
    KP_MODEL_TENSOR_DATA_LAYOUT_8W1C16B = 4


class ModelTargetChip(BaseIntEnum):
    """
    enum for model target chip.

    Attributes
    ----------
    KP_MODEL_TARGET_CHIP_UNKNOWN : int, default=0
        Model for unknown chip.
    KP_MODEL_TARGET_CHIP_KL520 : int, default=1
        Model for KL520.
    KP_MODEL_TARGET_CHIP_KL720 : int, default=2
        Model for KL720.
    KP_MODEL_TARGET_CHIP_KL530 : int, default=3
        Model for KL530.
    KP_MODEL_TARGET_CHIP_KL730 : int, default=4
        Model for KL730.
    KP_MODEL_TARGET_CHIP_KL630 : int, default=5
        Model for KL630.
    KP_MODEL_TARGET_CHIP_KL540 : int, default=6
        Model for KL540.
    """
    KP_MODEL_TARGET_CHIP_UNKNOWN = 0
    KP_MODEL_TARGET_CHIP_KL520 = 1
    KP_MODEL_TARGET_CHIP_KL720 = 2
    KP_MODEL_TARGET_CHIP_KL530 = 3
    KP_MODEL_TARGET_CHIP_KL730 = 4
    KP_MODEL_TARGET_CHIP_KL630 = 5
    KP_MODEL_TARGET_CHIP_KL540 = 6


class ApiReturnCode(BaseIntEnum):
    """
    Return code of PLUS APIs.

    Attributes
    ----------
    KP_SUCCESS : int, default=0

    KP_ERROR_USB_IO_N1 : int, default=-1
    KP_ERROR_USB_INVALID_PARAM_N2 : int, default=-2
    KP_ERROR_USB_ACCESS_N3 : int, default=-3
    KP_ERROR_USB_NO_DEVICE_N4 : int, default=-4
    KP_ERROR_USB_NOT_FOUND_N5 : int, default=-5
    KP_ERROR_USB_BUSY_N6 : int, default=-6
    KP_ERROR_USB_TIMEOUT_N7 : int, default=-7
    KP_ERROR_USB_OVERFLOW_N8 : int, default=-8
    KP_ERROR_USB_PIPE_N9 : int, default=-9
    KP_ERROR_USB_INTERRUPTED_N10 : int, default=-10
    KP_ERROR_USB_NO_MEM_N11 : int, default=-11
    KP_ERROR_USB_NOT_SUPPORTED_N12 : int, default=-12
    KP_ERROR_USB_OTHER_N99 : int, default=-99

    KP_ERROR_WDI_BEGIN : int, default=-200
    KP_ERROR_WDI_IO_N1 : int, default=-201
    KP_ERROR_WDI_INVALID_PARAM_N2 : int, default=-202
    KP_ERROR_WDI_ACCESS_N3 : int, default=-203
    KP_ERROR_WDI_NO_DEVICE_N4 : int, default=-204
    KP_ERROR_WDI_NOT_FOUND_N5 : int, default=-205
    KP_ERROR_WDI_BUSY_N6 : int, default=-206
    KP_ERROR_WDI_TIMEOUT_N7 : int, default=-207
    KP_ERROR_WDI_OVERFLOW_N8 : int, default=-208
    KP_ERROR_WDI_PENDING_INSTALLATION_N9 : int, default=-209
    KP_ERROR_WDI_INTERRUPTED_N10 : int, default=-210
    KP_ERROR_WDI_RESOURCE_N11 : int, default=-211
    KP_ERROR_WDI_NOT_SUPPORTED_N12 : int, default=-212
    KP_ERROR_WDI_EXISTS_N13 : int, default=-213
    KP_ERROR_WDI_USER_CANCEL_N14 : int, default=-214
    KP_ERROR_WDI_NEEDS_ADMIN_N15 : int, default=-215
    KP_ERROR_WDI_WOW64_N16 : int, default=-216
    KP_ERROR_WDI_INF_SYNTAX_N17 : int, default=-217
    KP_ERROR_WDI_CAT_MISSING_N18 : int, default=-218
    KP_ERROR_WDI_UNSIGNED_N19 : int, default=-219
    KP_ERROR_WDI_OTHER_N99 : int, default=-299

    KP_ERROR_DEVICE_NOT_EXIST_10 : int, default=10
    KP_ERROR_DEVICE_INCORRECT_RESPONSE_11 : int, default=11
    KP_ERROR_INVALID_PARAM_12 : int, default=12
    KP_ERROR_SEND_DESC_FAIL_13 : int, default=13
    KP_ERROR_SEND_DATA_FAIL_14 : int, default=14
    KP_ERROR_SEND_DATA_TOO_LARGE_15 : int, default=15
    KP_ERROR_RECV_DESC_FAIL_16 : int, default=16
    KP_ERROR_RECV_DATA_FAIL_17 : int, default=17
    KP_ERROR_RECV_DATA_TOO_LARGE_18 : int, default=18
    KP_ERROR_FW_UPDATE_FAILED_19 : int, default=19
    KP_ERROR_FILE_OPEN_FAILED_20 : int, default=20
    KP_ERROR_INVALID_MODEL_21 : int, default=21
    KP_ERROR_IMAGE_RESOLUTION_TOO_SMALL_22 : int, default=22
    KP_ERROR_IMAGE_ODD_WIDTH_23 : int, default=23
    KP_ERROR_INVALID_FIRMWARE_24 : int, default=24
    KP_ERROR_RESET_FAILED_25 : int, default=25
    KP_ERROR_DEVICES_NUMBER_26 : int, default=26
    KP_ERROR_CONFIGURE_DEVICE_27 : int, default=27
    KP_ERROR_CONNECT_FAILED_28 : int, default=28
    KP_ERROR_DEVICE_GROUP_MIX_PRODUCT_29 : int, default=29
    KP_ERROR_RECEIVE_INCORRECT_HEADER_STAMP_30 : int, default=30
    KP_ERROR_RECEIVE_SIZE_MISMATCH_31 : int, default=31
    KP_ERROR_RECEIVE_JOB_ID_MISMATCH_32 : int, default=32
    KP_ERROR_INVALID_CUSTOMIZED_JOB_ID_33 : int, default=33
    KP_ERROR_FW_LOAD_FAILED_34 : int, default=34
    KP_ERROR_MODEL_NOT_LOADED_35 : int, default=35
    KP_ERROR_INVALID_CHECKPOINT_DATA_36 : int, default=36
    KP_DBG_CHECKPOINT_END_37 : int, default=37
    KP_ERROR_INVALID_HOST_38 : int, default=38
    KP_ERROR_MEMORY_FREE_FAILURE_39 : int, default=39
    KP_ERROR_USB_BOOT_LOAD_SECOND_MODEL_40 : int, default=40
    KP_ERROR_CHECK_FW_VERSION_FAILED_41 : int, default=41
    KP_ERROR_FIFOQ_INPUT_BUFF_COUNT_NOT_ENOUGH_42 : int, default=42
    KP_ERROR_FIFOQ_SETTING_FAILED_43 : int, default=43
    KP_ERROR_UNSUPPORTED_DEVICE_44 : int, default=44
    KP_ERROR_IMAGE_INVALID_HEIGHT_45 : int, default=45
    KP_ERROR_ADJUST_DDR_HEAP_FAILED_46 : int, default=46
    KP_ERROR_DEVICE_NOT_ACCESSIBLE_47 : int, default=47
    KP_ERROR_INVALID_INPUT_NODE_DATA_NUMBER_48 : int, default=48

    KP_ERROR_OTHER_99 : int, default=99

    KP_FW_ERROR_UNKNOWN_APP : int, default=100
    KP_FW_INFERENCE_ERROR_101 : int, default=101
    KP_FW_DDR_MALLOC_FAILED_102 : int, default=102
    KP_FW_INFERENCE_TIMEOUT_103 : int, default=103
    KP_FW_LOAD_MODEL_FAILED_104 : int, default=104
    KP_FW_CONFIG_POST_PROC_ERROR_MALLOC_FAILED_105 : int, default=105
    KP_FW_CONFIG_POST_PROC_ERROR_NO_SPACE_106 : int, default=106
    KP_FW_IMAGE_SIZE_NOT_MATCH_MODEL_INPUT_107 : int, default=107
    KP_FW_NOT_SUPPORT_PREPROCESSING_108 : int, default=108
    KP_FW_GET_MODEL_INFO_FAILED_109 : int, default=109
    KP_FW_WRONG_INPUT_BUFFER_COUNT_110 : int, default=110
    KP_FW_INVALID_PRE_PROC_MODEL_INPUT_SIZE_111 : int, default=111
    KP_FW_INVALID_INPUT_CROP_PARAM_112 : int, default=112
    KP_FW_ERROR_FILE_OPEN_FAILED_113 : int, default=113
    KP_FW_ERROR_FILE_STATE_FAILED_114 : int, default=114
    KP_FW_ERROR_FILE_READ_FAILED_115 : int, default=115
    KP_FW_ERROR_FILE_WRITE_FAILED_116 : int, default=116
    KP_FW_ERROR_FILE_CHMOD_FAILED_117 : int, default=117
    KP_FW_ERROR_FILE_FAILED_OTHER_118 : int, default=118
    KP_FW_ERROR_INVALID_BOOT_CONFIG_119 : int, default=119
    KP_FW_ERROR_LOADER_ERROR_120 : int, default=120
    KP_FW_ERROR_POSIX_SPAWN_FAILED_121 : int, default=121
    KP_FW_ERROR_USB_SEND_FAILED_122 : int, default=122
    KP_FW_ERROR_USB_RECEIVE_FAILED_123 : int, default=123
    KP_FW_ERROR_HANDLE_NOT_READY_124 : int, default=124
    KP_FW_FIFOQ_ACCESS_FAILED_125 : int, default=125
    KP_FW_FIFOQ_NOT_READY_126 : int, default=126
    KP_FW_ERROR_FILE_SEEK_FAILED_127 : int, default=127
    KP_FW_ERROR_FILE_FLUSH_FAILED_128 : int, default=128
    KP_FW_ERROR_FILE_SYNC_FAILED_129 : int, default=129
    KP_FW_ERROR_FILE_CLOSE_FAILED_130 : int, default=130
    KP_FW_ERROR_MODEL_EXIST_CPU_NODE_131 : int, default=131
    KP_FW_ERROR_MODEL_EXIST_CONST_INPUT_NODE_132 : int, default=132
    KP_FW_ERROR_GET_MSG_QUEUE_FAILED_133 : int, default=133
    KP_FW_ERROR_SEND_MSG_QUEUE_FAILED_134 : int, default=134
    KP_FW_ERROR_RECV_MSG_QUEUE_FAILED_135 : int, default=135

    KP_FW_NCPU_ERR_BEGIN : int, default=200
    KP_FW_NCPU_INVALID_IMAGE_201 : int, default=201
    KP_FW_NCPU_INPROC_FAILED_202 : int, default=202

    KP_FW_EFUSE_CAN_NOT_BURN_300 : int, default=300
    KP_FW_EFUSE_PROTECTED_301 : int, default=301
    KP_FW_EFUSE_OTHER_302 : int, default=302

    KP_FW_APP_MASK_FDFR_ENROLL_WITH_MASKED_FACE_10000 : int, default=10000
    KP_FW_APP_SEG_INSUFFICIENT_RESULT_BUFFER_SIZE_10001 : int, default=10001
    """
    KP_SUCCESS = 0

    # libusb error code
    KP_ERROR_USB_IO_N1 = -1
    KP_ERROR_USB_INVALID_PARAM_N2 = -2
    KP_ERROR_USB_ACCESS_N3 = -3
    KP_ERROR_USB_NO_DEVICE_N4 = -4
    KP_ERROR_USB_NOT_FOUND_N5 = -5
    KP_ERROR_USB_BUSY_N6 = -6
    KP_ERROR_USB_TIMEOUT_N7 = -7
    KP_ERROR_USB_OVERFLOW_N8 = -8
    KP_ERROR_USB_PIPE_N9 = -9
    KP_ERROR_USB_INTERRUPTED_N10 = -10
    KP_ERROR_USB_NO_MEM_N11 = -11
    KP_ERROR_USB_NOT_SUPPORTED_N12 = -12
    KP_ERROR_USB_OTHER_N99 = -99

    # libwdi error code (remapping from: kneron_plus/thirdparty/windows/include/libwdi.h)
    KP_ERROR_WDI_BEGIN = -200
    KP_ERROR_WDI_IO_N1 = -201
    KP_ERROR_WDI_INVALID_PARAM_N2 = -202
    KP_ERROR_WDI_ACCESS_N3 = -203
    KP_ERROR_WDI_NO_DEVICE_N4 = -204
    KP_ERROR_WDI_NOT_FOUND_N5 = -205
    KP_ERROR_WDI_BUSY_N6 = -206
    KP_ERROR_WDI_TIMEOUT_N7 = -207
    KP_ERROR_WDI_OVERFLOW_N8 = -208
    KP_ERROR_WDI_PENDING_INSTALLATION_N9 = -209
    KP_ERROR_WDI_INTERRUPTED_N10 = -210
    KP_ERROR_WDI_RESOURCE_N11 = -211
    KP_ERROR_WDI_NOT_SUPPORTED_N12 = -212
    KP_ERROR_WDI_EXISTS_N13 = -213
    KP_ERROR_WDI_USER_CANCEL_N14 = -214
    KP_ERROR_WDI_NEEDS_ADMIN_N15 = -215
    KP_ERROR_WDI_WOW64_N16 = -216
    KP_ERROR_WDI_INF_SYNTAX_N17 = -217
    KP_ERROR_WDI_CAT_MISSING_N18 = -218
    KP_ERROR_WDI_UNSIGNED_N19 = -219
    KP_ERROR_WDI_OTHER_N99 = -299

    # host error code
    KP_ERROR_DEVICE_NOT_EXIST_10 = 10
    KP_ERROR_DEVICE_INCORRECT_RESPONSE_11 = 11
    KP_ERROR_INVALID_PARAM_12 = 12
    KP_ERROR_SEND_DESC_FAIL_13 = 13
    KP_ERROR_SEND_DATA_FAIL_14 = 14
    KP_ERROR_SEND_DATA_TOO_LARGE_15 = 15
    KP_ERROR_RECV_DESC_FAIL_16 = 16
    KP_ERROR_RECV_DATA_FAIL_17 = 17
    KP_ERROR_RECV_DATA_TOO_LARGE_18 = 18
    KP_ERROR_FW_UPDATE_FAILED_19 = 19
    KP_ERROR_FILE_OPEN_FAILED_20 = 20
    KP_ERROR_INVALID_MODEL_21 = 21
    KP_ERROR_IMAGE_RESOLUTION_TOO_SMALL_22 = 22
    KP_ERROR_IMAGE_ODD_WIDTH_23 = 23
    KP_ERROR_INVALID_FIRMWARE_24 = 24
    KP_ERROR_RESET_FAILED_25 = 25
    KP_ERROR_DEVICES_NUMBER_26 = 26
    KP_ERROR_CONFIGURE_DEVICE_27 = 27
    KP_ERROR_CONNECT_FAILED_28 = 28
    KP_ERROR_DEVICE_GROUP_MIX_PRODUCT_29 = 29
    KP_ERROR_RECEIVE_INCORRECT_HEADER_STAMP_30 = 30
    KP_ERROR_RECEIVE_SIZE_MISMATCH_31 = 31
    KP_ERROR_RECEIVE_JOB_ID_MISMATCH_32 = 32
    KP_ERROR_INVALID_CUSTOMIZED_JOB_ID_33 = 33
    KP_ERROR_FW_LOAD_FAILED_34 = 34
    KP_ERROR_MODEL_NOT_LOADED_35 = 35
    KP_ERROR_INVALID_CHECKPOINT_DATA_36 = 36
    KP_DBG_CHECKPOINT_END_37 = 37
    KP_ERROR_INVALID_HOST_38 = 38
    KP_ERROR_MEMORY_FREE_FAILURE_39 = 39
    KP_ERROR_USB_BOOT_LOAD_SECOND_MODEL_40 = 40
    KP_ERROR_CHECK_FW_VERSION_FAILED_41 = 41
    KP_ERROR_FIFOQ_INPUT_BUFF_COUNT_NOT_ENOUGH_42 = 42
    KP_ERROR_FIFOQ_SETTING_FAILED_43 = 43
    KP_ERROR_UNSUPPORTED_DEVICE_44 = 44
    KP_ERROR_IMAGE_INVALID_HEIGHT_45 = 45
    KP_ERROR_ADJUST_DDR_HEAP_FAILED_46 = 46
    KP_ERROR_DEVICE_NOT_ACCESSIBLE_47 = 47
    KP_ERROR_INVALID_INPUT_NODE_DATA_NUMBER_48 = 48

    KP_ERROR_OTHER_99 = 99

    # firmware error code
    KP_FW_ERROR_UNKNOWN_APP = 100
    KP_FW_INFERENCE_ERROR_101 = 101
    KP_FW_DDR_MALLOC_FAILED_102 = 102
    KP_FW_INFERENCE_TIMEOUT_103 = 103
    KP_FW_LOAD_MODEL_FAILED_104 = 104
    KP_FW_CONFIG_POST_PROC_ERROR_MALLOC_FAILED_105 = 105
    KP_FW_CONFIG_POST_PROC_ERROR_NO_SPACE_106 = 106
    KP_FW_IMAGE_SIZE_NOT_MATCH_MODEL_INPUT_107 = 107
    KP_FW_NOT_SUPPORT_PREPROCESSING_108 = 108
    KP_FW_GET_MODEL_INFO_FAILED_109 = 109
    KP_FW_WRONG_INPUT_BUFFER_COUNT_110 = 110
    KP_FW_INVALID_PRE_PROC_MODEL_INPUT_SIZE_111 = 111
    KP_FW_INVALID_INPUT_CROP_PARAM_112 = 112
    KP_FW_ERROR_FILE_OPEN_FAILED_113 = 113
    KP_FW_ERROR_FILE_STATE_FAILED_114 = 114
    KP_FW_ERROR_FILE_READ_FAILED_115 = 115
    KP_FW_ERROR_FILE_WRITE_FAILED_116 = 116
    KP_FW_ERROR_FILE_CHMOD_FAILED_117 = 117
    KP_FW_ERROR_FILE_FAILED_OTHER_118 = 118
    KP_FW_ERROR_INVALID_BOOT_CONFIG_119 = 119
    KP_FW_ERROR_LOADER_ERROR_120 = 120
    KP_FW_ERROR_POSIX_SPAWN_FAILED_121 = 121
    KP_FW_ERROR_USB_SEND_FAILED_122 = 122
    KP_FW_ERROR_USB_RECEIVE_FAILED_123 = 123
    KP_FW_ERROR_HANDLE_NOT_READY_124 = 124
    KP_FW_FIFOQ_ACCESS_FAILED_125 = 125
    KP_FW_FIFOQ_NOT_READY_126 = 126
    KP_FW_ERROR_FILE_SEEK_FAILED_127 = 127
    KP_FW_ERROR_FILE_FLUSH_FAILED_128 = 128
    KP_FW_ERROR_FILE_SYNC_FAILED_129 = 129
    KP_FW_ERROR_FILE_CLOSE_FAILED_130 = 130
    KP_FW_ERROR_MODEL_EXIST_CPU_NODE_131 = 131
    KP_FW_ERROR_MODEL_EXIST_CONST_INPUT_NODE_132 = 132
    KP_FW_ERROR_GET_MSG_QUEUE_FAILED_133 = 133
    KP_FW_ERROR_SEND_MSG_QUEUE_FAILED_134 = 134
    KP_FW_ERROR_RECV_MSG_QUEUE_FAILED_135 = 135

    # ncpu error code (sync with ipc.h)
    KP_FW_NCPU_ERR_BEGIN = 200
    KP_FW_NCPU_INVALID_IMAGE_201 = 201
    KP_FW_NCPU_INPROC_FAILED_202 = 202

    # firmware eFuse error code
    KP_FW_EFUSE_CAN_NOT_BURN_300 = 300
    KP_FW_EFUSE_PROTECTED_301 = 301
    KP_FW_EFUSE_OTHER_302 = 302

    # firmware APP error code
    # mask_fdfr error code
    KP_FW_APP_MASK_FDFR_ENROLL_WITH_MASKED_FACE_10000 = 10000

    # seg error code
    KP_FW_APP_SEG_INSUFFICIENT_RESULT_BUFFER_SIZE_10001 = 10001
