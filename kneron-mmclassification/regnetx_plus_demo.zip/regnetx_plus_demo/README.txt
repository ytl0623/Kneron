
Python libs requirement:
	1. Kneron plus v0.13.0
	2. Numpy
	3. OpenCV-Python



How to run this example:

	python KL720DemoGenericInferenceRegNetX_BypassHwPreProc.py -nef example_RegNetX_720.nef -img shark.jpg